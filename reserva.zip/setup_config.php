<?php
// Configuration key for initial system setup
define('SETUP_KEY', 'alugafacil2023setup');