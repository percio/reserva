<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    redirect('../login.php');
}

// Processar ações
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];
    
    switch ($action) {
        case 'activate':
            try {
                $stmt = $pdo->prepare("UPDATE usuarios SET status = 'ativo' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Usuário ativado com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao ativar usuário: " . $e->getMessage();
            }
            break;
            
        case 'deactivate':
            try {
                $stmt = $pdo->prepare("UPDATE usuarios SET status = 'inativo' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Usuário desativado com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao desativar usuário: " . $e->getMessage();
            }
            break;
            
        case 'delete':
            try {
                $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ? AND tipo != 'admin'");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    $_SESSION['success'] = "Usuário excluído com sucesso!";
                } else {
                    $_SESSION['error'] = "Não é possível excluir um administrador!";
                }
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao excluir usuário: " . $e->getMessage();
            }
            break;
    }
    
    redirect('usuarios.php');
}

// Paginação e busca
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? $_GET['search'] : '';
$where = '';
$params = [];

if (!empty($search)) {
    $where = " WHERE nome LIKE ? OR email LIKE ? OR telefone LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%"];
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios" . $where);
$stmt->execute($params);
$total_usuarios = $stmt->fetchColumn();
$total_pages = ceil($total_usuarios / $limit);

$stmt = $pdo->prepare("SELECT * FROM usuarios" . $where . " ORDER BY nome LIMIT ?, ?");
$params[] = $offset;
$params[] = $limit;
$stmt->execute($params);
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Gerenciar Usuários</h2>
                </div>
                <div class="dashboard-actions">
                    <a href="usuario-novo.php" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i> Adicionar Usuário
                    </a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-table">
                <div class="card">
                    <div class="card-body">
                        <form action="usuarios.php" method="GET" class="mb-4">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Buscar por nome, email ou telefone" value="<?php echo htmlspecialchars($search); ?>">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Buscar
                                </button>
                            </div>
                        </form>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nome</th>
                                        <th>Email</th>
                                        <th>Telefone</th>
                                        <th>Tipo</th>
                                        <th>Status</th>
                                        <th>Cadastro</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($usuarios)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">Nenhum usuário encontrado</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($usuarios as $usuario): ?>
                                            <tr>
                                                <td><?php echo $usuario['id']; ?></td>
                                                <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                                                <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                                                <td><?php echo htmlspecialchars($usuario['telefone']); ?></td>
                                                <td>
                                                    <span class="badge <?php echo $usuario['tipo'] === 'admin' ? 'bg-danger' : 'bg-primary'; ?>">
                                                        <?php echo ucfirst($usuario['tipo']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    switch ($usuario['status']) {
                                                        case 'ativo':
                                                            $status_class = 'bg-success';
                                                            break;
                                                        case 'pendente':
                                                            $status_class = 'bg-warning';
                                                            break;
                                                        case 'inativo':
                                                            $status_class = 'bg-danger';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($usuario['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d/m/Y', strtotime($usuario['data_cadastro'])); ?></td>
                                                <td>
                                                    <a href="usuario-editar.php?id=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    
                                                    <?php if ($usuario['status'] !== 'ativo'): ?>
                                                        <a href="usuarios.php?action=activate&id=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-success" title="Ativar">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($usuario['status'] !== 'inativo' && $usuario['tipo'] !== 'admin'): ?>
                                                        <a href="usuarios.php?action=deactivate&id=<?php echo $usuario['id']; ?>" class="btn btn-sm btn-warning" title="Desativar">
                                                            <i class="fas fa-ban"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($usuario['tipo'] !== 'admin'): ?>
                                                        <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $usuario['id']; ?>" title="Excluir">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                        
                                                        <!-- Delete Modal -->
                                                        <div class="modal fade" id="deleteModal<?php echo $usuario['id']; ?>" tabindex="-1" aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p>Tem certeza que deseja excluir o usuário "<?php echo htmlspecialchars($usuario['nome']); ?>"?</p>
                                                                        <p class="text-danger">Esta ação não pode ser desfeita!</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                        <a href="usuarios.php?action=delete&id=<?php echo $usuario['id']; ?>" class="btn btn-danger">Excluir</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=1<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                <i class="fas fa-angle-double-left"></i>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                <i class="fas fa-angle-left"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php
                                    $start_page = max(1, $page - 2);
                                    $end_page = min($total_pages, $page + 2);
                                    
                                    for ($i = $start_page; $i <= $end_page; $i++):
                                    ?>
                                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                <i class="fas fa-angle-right"></i>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                <i class="fas fa-angle-double-right"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>