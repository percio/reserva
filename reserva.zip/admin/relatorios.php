<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    redirect('../login.php');
}

// Processar solicitação de relatório
$report_type = isset($_GET['type']) ? $_GET['type'] : '';
$data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : date('Y-m-01'); // Primeiro dia do mês atual
$data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : date('Y-m-t'); // Último dia do mês atual

// Dados padrão
$report_data = [];
$report_title = '';

// Gerar relatório conforme o tipo selecionado
if (!empty($report_type)) {
    switch ($report_type) {
        case 'reservas':
            $report_title = 'Relatório de Reservas';
            
            // Buscar reservas por período
            $sql = "
                SELECT r.*, u.nome as usuario_nome, i.titulo as imovel_titulo
                FROM reservas r
                JOIN usuarios u ON r.id_usuario = u.id
                JOIN imoveis i ON r.id_imovel = i.id
                WHERE r.data_reserva BETWEEN ? AND ?
                ORDER BY r.data_reserva DESC
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data_inicio, $data_fim]);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calcular total de reservas e valor
            $total_reservas = count($report_data);
            $total_valor = array_sum(array_column($report_data, 'valor_total'));
            
            // Agrupar por status
            $status_counts = array_count_values(array_column($report_data, 'status'));
            break;
            
        case 'faturamento':
            $report_title = 'Relatório de Faturamento';
            
            // Buscar receitas por período agrupadas por mês
            $sql = "
                SELECT 
                    DATE_FORMAT(data_reserva, '%Y-%m') as mes,
                    COUNT(*) as total_reservas,
                    SUM(valor_total) as receita_total
                FROM reservas
                WHERE status = 'confirmada' AND data_reserva BETWEEN ? AND ?
                GROUP BY DATE_FORMAT(data_reserva, '%Y-%m')
                ORDER BY mes
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data_inicio, $data_fim]);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Preparar dados para o gráfico
            $labels = [];
            $values = [];
            
            foreach ($report_data as $item) {
                $month_year = explode('-', $item['mes']);
                $month_name = date('M', mktime(0, 0, 0, $month_year[1], 1));
                $labels[] = $month_name . '/' . $month_year[0];
                $values[] = $item['receita_total'];
            }
            break;
            
        case 'imoveis_populares':
            $report_title = 'Imóveis Mais Populares';
            
            // Buscar imóveis mais reservados
            $sql = "
                SELECT 
                    i.id, i.titulo, i.cidade, i.estado,
                    COUNT(r.id) as total_reservas,
                    SUM(r.valor_total) as receita_total
                FROM imoveis i
                JOIN reservas r ON i.id = r.id_imovel
                WHERE r.status = 'confirmada' AND r.data_reserva BETWEEN ? AND ?
                GROUP BY i.id
                ORDER BY total_reservas DESC
                LIMIT 10
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data_inicio, $data_fim]);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'clientes':
            $report_title = 'Relatório de Clientes';
            
            // Buscar clientes mais ativos
            $sql = "
                SELECT 
                    u.id, u.nome, u.email, u.telefone,
                    COUNT(r.id) as total_reservas,
                    SUM(r.valor_total) as total_gasto
                FROM usuarios u
                LEFT JOIN reservas r ON u.id = r.id_usuario AND r.status = 'confirmada' AND r.data_reserva BETWEEN ? AND ?
                WHERE u.tipo = 'cliente'
                GROUP BY u.id
                ORDER BY total_reservas DESC
                LIMIT 10
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data_inicio, $data_fim]);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Relatórios Gerenciais</h2>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form action="relatorios.php" method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label for="type" class="form-label">Tipo de Relatório</label>
                            <select name="type" id="type" class="form-select" required>
                                <option value="">Selecione um relatório</option>
                                <option value="reservas" <?php echo $report_type === 'reservas' ? 'selected' : ''; ?>>Reservas</option>
                                <option value="faturamento" <?php echo $report_type === 'faturamento' ? 'selected' : ''; ?>>Faturamento</option>
                                <option value="imoveis_populares" <?php echo $report_type === 'imoveis_populares' ? 'selected' : ''; ?>>Imóveis Mais Populares</option>
                                <option value="clientes" <?php echo $report_type === 'clientes' ? 'selected' : ''; ?>>Clientes</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?php echo $data_inicio; ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?php echo $data_fim; ?>" required>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Gerar Relatório</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if (!empty($report_type) && !empty($report_data)): ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo $report_title; ?></h5>
                        <div>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="window.print()">
                                <i class="fas fa-print"></i> Imprimir
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success" id="exportExcel">
                                <i class="fas fa-file-excel"></i> Exportar Excel
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger" id="exportPDF">
                                <i class="fas fa-file-pdf"></i> Exportar PDF
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($report_type === 'reservas'): ?>
                            <div class="row mb-4">
                                <div class="col-md-3">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body">
                                            <h5 class="card-title">Total de Reservas</h5>
                                            <p class="card-text display-6"><?php echo $total_reservas; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card bg-success text-white">
                                        <div class="card-body">
                                            <h5 class="card-title">Valor Total</h5>
                                            <p class="card-text display-6">R$ <?php echo number_format($total_valor, 2, ',', '.'); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Reservas por Status</h5>
                                            <canvas id="statusChart" height="100"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Cliente</th>
                                            <th>Imóvel</th>
                                            <th>Check-in</th>
                                            <th>Check-out</th>
                                            <th>Valor</th>
                                            <th>Status</th>
                                            <th>Data Reserva</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $reserva): ?>
                                            <tr>
                                                <td><?php echo $reserva['id']; ?></td>
                                                <td><?php echo htmlspecialchars($reserva['usuario_nome']); ?></td>
                                                <td><?php echo htmlspecialchars($reserva['imovel_titulo']); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?></td>
                                                <td>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    switch ($reserva['status']) {
                                                        case 'pendente':
                                                            $status_class = 'bg-warning';
                                                            break;
                                                        case 'confirmada':
                                                            $status_class = 'bg-success';
                                                            break;
                                                        case 'cancelada':
                                                            $status_class = 'bg-danger';
                                                            break;
                                                        case 'concluida':
                                                            $status_class = 'bg-secondary';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($reserva['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($reserva['data_reserva'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    // Status chart
                                    const statusCtx = document.getElementById('statusChart');
                                    new Chart(statusCtx, {
                                        type: 'pie',
                                        data: {
                                            labels: [
                                                'Pendente', 
                                                'Confirmada', 
                                                'Cancelada', 
                                                'Concluída'
                                            ],
                                            datasets: [{
                                                label: 'Reservas',
                                                data: [
                                                    <?php echo isset($status_counts['pendente']) ? $status_counts['pendente'] : 0; ?>,
                                                    <?php echo isset($status_counts['confirmada']) ? $status_counts['confirmada'] : 0; ?>,
                                                    <?php echo isset($status_counts['cancelada']) ? $status_counts['cancelada'] : 0; ?>,
                                                    <?php echo isset($status_counts['concluida']) ? $status_counts['concluida'] : 0; ?>
                                                ],
                                                backgroundColor: [
                                                    '#ffc107',
                                                    '#28a745',
                                                    '#dc3545',
                                                    '#6c757d'
                                                ],
                                                borderWidth: 1
                                            }]
                                        }
                                    });
                                });
                            </script>
                        <?php elseif ($report_type === 'faturamento'): ?>
                            <div class="chart-container mb-4">
                                <canvas id="faturamentoChart" height="100"></canvas>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Mês</th>
                                            <th>Total de Reservas</th>
                                            <th>Receita Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $item): ?>
                                            <tr>
                                                <?php
                                                $month_year = explode('-', $item['mes']);
                                                $month_name = date('F', mktime(0, 0, 0, $month_year[1], 1));
                                                ?>
                                                <td><?php echo $month_name . ' ' . $month_year[0]; ?></td>
                                                <td><?php echo $item['total_reservas']; ?></td>
                                                <td>R$ <?php echo number_format($item['receita_total'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    // Faturamento chart
                                    const faturamentoCtx = document.getElementById('faturamentoChart');
                                    new Chart(faturamentoCtx, {
                                        type: 'bar',
                                        data: {
                                            labels: <?php echo json_encode($labels); ?>,
                                            datasets: [{
                                                label: 'Faturamento (R$)',
                                                data: <?php echo json_encode($values); ?>,
                                                backgroundColor: 'rgba(52, 152, 219, 0.7)',
                                                borderColor: 'rgba(52, 152, 219, 1)',
                                                borderWidth: 1
                                            }]
                                        },
                                        options: {
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
                        <?php elseif ($report_type === 'imoveis_populares'): ?>
                            <div class="chart-container mb-4">
                                <canvas id="imoveisChart" height="150"></canvas>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Imóvel</th>
                                            <th>Localização</th>
                                            <th>Total de Reservas</th>
                                            <th>Receita Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $imovel): ?>
                                            <tr>
                                                <td><?php echo $imovel['id']; ?></td>
                                                <td><?php echo htmlspecialchars($imovel['titulo']); ?></td>
                                                <td><?php echo htmlspecialchars($imovel['cidade'] . ', ' . $imovel['estado']); ?></td>
                                                <td><?php echo $imovel['total_reservas']; ?></td>
                                                <td>R$ <?php echo number_format($imovel['receita_total'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    // Imóveis chart
                                    const imoveisCtx = document.getElementById('imoveisChart');
                                    new Chart(imoveisCtx, {
                                        type: 'bar',
                                        data: {
                                            labels: <?php echo json_encode(array_map(function($item) { return substr($item['titulo'], 0, 30); }, $report_data)); ?>,
                                            datasets: [{
                                                label: 'Total de Reservas',
                                                data: <?php echo json_encode(array_map(function($item) { return $item['total_reservas']; }, $report_data)); ?>,
                                                backgroundColor: 'rgba(52, 152, 219, 0.7)',
                                                borderColor: 'rgba(52, 152, 219, 1)',
                                                borderWidth: 1
                                            }]
                                        },
                                        options: {
                                            indexAxis: 'y',
                                            scales: {
                                                x: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
                        <?php elseif ($report_type === 'clientes'): ?>
                            <div class="chart-container mb-4">
                                <canvas id="clientesChart" height="150"></canvas>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nome</th>
                                            <th>Email</th>
                                            <th>Telefone</th>
                                            <th>Total de Reservas</th>
                                            <th>Total Gasto</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $cliente): ?>
                                            <tr>
                                                <td><?php echo $cliente['id']; ?></td>
                                                <td><?php echo htmlspecialchars($cliente['nome']); ?></td>
                                                <td><?php echo htmlspecialchars($cliente['email']); ?></td>
                                                <td><?php echo htmlspecialchars($cliente['telefone']); ?></td>
                                                <td><?php echo $cliente['total_reservas']; ?></td>
                                                <td>R$ <?php echo number_format($cliente['total_gasto'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    // Clientes chart
                                    const clientesCtx = document.getElementById('clientesChart');
                                    new Chart(clientesCtx, {
                                        type: 'bar',
                                        data: {
                                            labels: <?php echo json_encode(array_map(function($item) { return $item['nome']; }, $report_data)); ?>,
                                            datasets: [{
                                                label: 'Total Gasto (R$)',
                                                data: <?php echo json_encode(array_map(function($item) { return $item['total_gasto']; }, $report_data)); ?>,
                                                backgroundColor: 'rgba(46, 204, 113, 0.7)',
                                                borderColor: 'rgba(46, 204, 113, 1)',
                                                borderWidth: 1
                                            }]
                                        },
                                        options: {
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
                        <?php endif; ?>
                    </div>
                </div>
            <?php elseif (!empty($report_type)): ?>
                <div class="alert alert-info">
                    Nenhum dado encontrado para o período selecionado.
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>