<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    redirect('../login.php');
}

// Processar formulário de configurações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = filter_input(INPUT_POST, 'site_name', FILTER_SANITIZE_STRING);
    $admin_email = filter_input(INPUT_POST, 'admin_email', FILTER_SANITIZE_EMAIL);
    $contact_phone = filter_input(INPUT_POST, 'contact_phone', FILTER_SANITIZE_STRING);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $facebook = filter_input(INPUT_POST, 'facebook', FILTER_SANITIZE_URL);
    $instagram = filter_input(INPUT_POST, 'instagram', FILTER_SANITIZE_URL);
    $twitter = filter_input(INPUT_POST, 'twitter', FILTER_SANITIZE_URL);
    $whatsapp = filter_input(INPUT_POST, 'whatsapp', FILTER_SANITIZE_STRING);
    
    // TODO: Implementar a lógica para salvar as configurações em um arquivo ou banco de dados
    
    $_SESSION['success'] = "Configurações atualizadas com sucesso!";
    redirect('configuracoes.php');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Configurações do Sistema</h2>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" id="configTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button" role="tab" aria-controls="general" aria-selected="true">Geral</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Contato</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="social-tab" data-bs-toggle="tab" data-bs-target="#social" type="button" role="tab" aria-controls="social" aria-selected="false">Redes Sociais</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="email-tab" data-bs-toggle="tab" data-bs-target="#email" type="button" role="tab" aria-controls="email" aria-selected="false">E-mail</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="backup-tab" data-bs-toggle="tab" data-bs-target="#backup" type="button" role="tab" aria-controls="backup" aria-selected="false">Backup</button>
                        </li>
                    </ul>
                    
                    <div class="tab-content p-4" id="configTabsContent">
                        <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                            <form action="configuracoes.php" method="POST">
                                <div class="mb-3">
                                    <label for="site_name" class="form-label">Nome do Site</label>
                                    <input type="text" class="form-control" id="site_name" name="site_name" value="AlugaFácil" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="site_description" class="form-label">Descrição do Site</label>
                                    <textarea class="form-control" id="site_description" name="site_description" rows="3">Sua melhor opção para aluguel de temporada no litoral.</textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="admin_email" class="form-label">Email do Administrador</label>
                                    <input type="email" class="form-control" id="admin_email" name="admin_email" value="admin@alugafacil.com.br" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="items_per_page" class="form-label">Itens por Página</label>
                                    <input type="number" class="form-control" id="items_per_page" name="items_per_page" value="10" min="5" max="50" required>
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                </div>
                            </form>
                        </div>
                        
                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                            <form action="configuracoes.php" method="POST">
                                <div class="mb-3">
                                    <label for="contact_email" class="form-label">Email de Contato</label>
                                    <input type="email" class="form-control" id="contact_email" name="contact_email" value="contato@alugafacil.com.br" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="contact_phone" class="form-label">Telefone de Contato</label>
                                    <input type="text" class="form-control" id="contact_phone" name="contact_phone" value="(12) 3456-7890" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="whatsapp" class="form-label">WhatsApp</label>
                                    <input type="text" class="form-control" id="whatsapp" name="whatsapp" value="(12) 98765-4321">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="address" class="form-label">Endereço</label>
                                    <textarea class="form-control" id="address" name="address" rows="3">Av. Beira Mar, 1000 - Caraguatatuba, SP</textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="business_hours" class="form-label">Horário de Funcionamento</label>
                                    <textarea class="form-control" id="business_hours" name="business_hours" rows="3">Segunda a Sexta: 9h às 18h
Sábado: 9h às 13h</textarea>
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                </div>
                            </form>
                        </div>
                        
                        <div class="tab-pane fade" id="social" role="tabpanel" aria-labelledby="social-tab">
                            <form action="configuracoes.php" method="POST">
                                <div class="mb-3">
                                    <label for="facebook" class="form-label">Facebook</label>
                                    <input type="url" class="form-control" id="facebook" name="facebook" value="https://facebook.com/alugafacil">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="instagram" class="form-label">Instagram</label>
                                    <input type="url" class="form-control" id="instagram" name="instagram" value="https://instagram.com/alugafacil">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="twitter" class="form-label">Twitter</label>
                                    <input type="url" class="form-control" id="twitter" name="twitter" value="https://twitter.com/alugafacil">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="youtube" class="form-label">YouTube</label>
                                    <input type="url" class="form-control" id="youtube" name="youtube" value="">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="linkedin" class="form-label">LinkedIn</label>
                                    <input type="url" class="form-control" id="linkedin" name="linkedin" value="">
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                </div>
                            </form>
                        </div>
                        
                        <div class="tab-pane fade" id="email" role="tabpanel" aria-labelledby="email-tab">
                            <form action="configuracoes.php" method="POST">
                                <div class="mb-3">
                                    <label for="smtp_host" class="form-label">SMTP Host</label>
                                    <input type="text" class="form-control" id="smtp_host" name="smtp_host" value="smtp.example.com">
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="smtp_port" class="form-label">SMTP Port</label>
                                        <input type="number" class="form-control" id="smtp_port" name="smtp_port" value="587">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="smtp_security" class="form-label">SMTP Security</label>
                                        <select class="form-select" id="smtp_security" name="smtp_security">
                                            <option value="tls" selected>TLS</option>
                                            <option value="ssl">SSL</option>
                                            <option value="none">None</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="smtp_username" class="form-label">SMTP Username</label>
                                    <input type="text" class="form-control" id="smtp_username" name="smtp_username" value="">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="smtp_password" class="form-label">SMTP Password</label>
                                    <input type="password" class="form-control" id="smtp_password" name="smtp_password" value="">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="from_email" class="form-label">From Email</label>
                                    <input type="email" class="form-control" id="from_email" name="from_email" value="no-reply@alugafacil.com.br">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="from_name" class="form-label">From Name</label>
                                    <input type="text" class="form-control" id="from_name" name="from_name" value="AlugaFácil">
                                </div>
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="button" class="btn btn-info me-md-2">Testar Conexão</button>
                                    <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                </div>
                            </form>
                        </div>
                        
                        <div class="tab-pane fade" id="backup" role="tabpanel" aria-labelledby="backup-tab">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> Mantenha backups regulares do seu banco de dados para garantir a segurança dos seus dados.
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    Backup Manual
                                </div>
                                <div class="card-body">
                                    <p>Crie um backup completo do banco de dados e arquivos do sistema.</p>
                                    <button type="button" class="btn btn-primary">
                                        <i class="fas fa-download"></i> Gerar Backup Completo
                                    </button>
                                    <button type="button" class="btn btn-outline-primary">
                                        <i class="fas fa-database"></i> Backup Somente do Banco de Dados
                                    </button>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    Backups Automáticos
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="auto_backup" class="form-label">Habilitar Backup Automático</label>
                                        <select class="form-select" id="auto_backup" name="auto_backup">
                                            <option value="1">Sim</option>
                                            <option value="0" selected>Não</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="backup_frequency" class="form-label">Frequência de Backup</label>
                                        <select class="form-select" id="backup_frequency" name="backup_frequency">
                                            <option value="daily">Diariamente</option>
                                            <option value="weekly" selected>Semanalmente</option>
                                            <option value="monthly">Mensalmente</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="backup_retention" class="form-label">Manter Backups por</label>
                                        <select class="form-select" id="backup_retention" name="backup_retention">
                                            <option value="7">7 dias</option>
                                            <option value="14">14 dias</option>
                                            <option value="30" selected>30 dias</option>
                                            <option value="90">90 dias</option>
                                            <option value="365">1 ano</option>
                                        </select>
                                    </div>
                                    
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>