<div class="sidebar">
    <div class="sidebar-header">
        <h3>Admin<span>Painel</span></h3>
    </div>
    
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="imoveis.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'imoveis.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Imóveis</span>
                </a>
            </li>
            <li>
                <a href="reservas.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'reservas.php' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-check"></i>
                    <span>Reservas</span>
                </a>
            </li>
            <li>
                <a href="usuarios.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i>
                    <span>Usuários</span>
                </a>
            </li>
            <li>
                <a href="avaliacoes.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'avaliacoes.php' ? 'active' : ''; ?>">
                    <i class="fas fa-star"></i>
                    <span>Avaliações</span>
                </a>
            </li>
            <li>
                <a href="mensagens.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'mensagens.php' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i>
                    <span>Mensagens</span>
                </a>
            </li>
            <li>
                <a href="configuracoes.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'configuracoes.php' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i>
                    <span>Configurações</span>
                </a>
            </li>
            <li>
                <a href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </li>
        </ul>
    </div>
</div>

