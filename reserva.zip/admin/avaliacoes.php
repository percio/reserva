<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    redirect('../login.php');
}

// Processar ações
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];
    
    switch ($action) {
        case 'approve':
            try {
                $stmt = $pdo->prepare("UPDATE avaliacoes SET status = 'aprovada' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Avaliação aprovada com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao aprovar avaliação: " . $e->getMessage();
            }
            break;
            
        case 'reject':
            try {
                $stmt = $pdo->prepare("UPDATE avaliacoes SET status = 'rejeitada' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Avaliação rejeitada com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao rejeitar avaliação: " . $e->getMessage();
            }
            break;
            
        case 'delete':
            try {
                $stmt = $pdo->prepare("DELETE FROM avaliacoes WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Avaliação excluída com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao excluir avaliação: " . $e->getMessage();
            }
            break;
    }
    
    redirect('avaliacoes.php');
}

// Filtros
$status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Paginação
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Construir a consulta SQL
$where_clauses = [];
$params = [];

if (!empty($status)) {
    $where_clauses[] = "a.status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $where_clauses[] = "(u.nome LIKE ? OR i.titulo LIKE ? OR a.comentario LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where = '';
if (!empty($where_clauses)) {
    $where = " WHERE " . implode(" AND ", $where_clauses);
}

// Total de registros para paginação
$sql_count = "
    SELECT COUNT(*) 
    FROM avaliacoes a
    JOIN usuarios u ON a.id_usuario = u.id
    JOIN imoveis i ON a.id_imovel = i.id
    $where
";

$stmt = $pdo->prepare($sql_count);
$stmt->execute($params);
$total_avaliacoes = $stmt->fetchColumn();
$total_pages = ceil($total_avaliacoes / $limit);

// Buscar avaliações
$sql = "
    SELECT a.*, u.nome as usuario_nome, u.email as usuario_email, 
           i.titulo as imovel_titulo, i.cidade as imovel_cidade, i.estado as imovel_estado
    FROM avaliacoes a
    JOIN usuarios u ON a.id_usuario = u.id
    JOIN imoveis i ON a.id_imovel = i.id
    $where
    ORDER BY a.data_avaliacao DESC
    LIMIT ?, ?
";

$stmt = $pdo->prepare($sql);
$params[] = $offset;
$params[] = $limit;
$stmt->execute($params);
$avaliacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Avaliações - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Gerenciar Avaliações</h2>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-table">
                <div class="card">
                    <div class="card-body">
                        <form action="avaliacoes.php" method="GET" class="mb-4">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <select name="status" class="form-select">
                                        <option value="">Todos os status</option>
                                        <option value="pendente" <?php echo $status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                        <option value="aprovada" <?php echo $status === 'aprovada' ? 'selected' : ''; ?>>Aprovada</option>
                                        <option value="rejeitada" <?php echo $status === 'rejeitada' ? 'selected' : ''; ?>>Rejeitada</option>
                                    </select>
                                </div>
                                <div class="col-md-7">
                                    <input type="text" name="search" class="form-control" placeholder="Buscar por nome do usuário, imóvel ou comentário" value="<?php echo htmlspecialchars($search); ?>">
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-search"></i> Filtrar
                                    </button>
                                </div>
                            </div>
                        </form>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Usuário</th>
                                        <th>Imóvel</th>
                                        <th>Nota</th>
                                        <th>Comentário</th>
                                        <th>Data</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($avaliacoes)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">Nenhuma avaliação encontrada</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($avaliacoes as $avaliacao): ?>
                                            <tr>
                                                <td><?php echo $avaliacao['id']; ?></td>
                                                <td><?php echo htmlspecialchars($avaliacao['usuario_nome']); ?></td>
                                                <td><?php echo htmlspecialchars($avaliacao['imovel_titulo']); ?></td>
                                                <td>
                                                    <div class="rating">
                                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                                            <i class="fas fa-star <?php echo $i <= $avaliacao['nota'] ? 'text-warning' : 'text-muted'; ?>"></i>
                                                        <?php endfor; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo substr(htmlspecialchars($avaliacao['comentario']), 0, 50); ?>
                                                    <?php if (strlen($avaliacao['comentario']) > 50): ?>...<?php endif; ?>
                                                </td>
                                                <td><?php echo date('d/m/Y', strtotime($avaliacao['data_avaliacao'])); ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    $status_text = '';
                                                    
                                                    switch ($avaliacao['status']) {
                                                        case 'pendente':
                                                            $status_class = 'bg-warning';
                                                            $status_text = 'Pendente';
                                                            break;
                                                        case 'aprovada':
                                                            $status_class = 'bg-success';
                                                            $status_text = 'Aprovada';
                                                            break;
                                                        case 'rejeitada':
                                                            $status_class = 'bg-danger';
                                                            $status_text = 'Rejeitada';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo $status_text; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="avaliacao-visualizar.php?id=<?php echo $avaliacao['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    
                                                    <?php if ($avaliacao['status'] === 'pendente'): ?>
                                                        <a href="avaliacoes.php?action=approve&id=<?php echo $avaliacao['id']; ?>" class="btn btn-sm btn-success">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        <a href="avaliacoes.php?action=reject&id=<?php echo $avaliacao['id']; ?>" class="btn btn-sm btn-danger">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    
                                                    <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $avaliacao['id']; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                    
                                                    <!-- Delete Modal -->
                                                    <div class="modal fade" id="deleteModal<?php echo $avaliacao['id']; ?>" tabindex="-1" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Tem certeza que deseja excluir esta avaliação?</p>
                                                                    <p class="text-danger">Esta ação não pode ser desfeita!</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                    <a href="avaliacoes.php?action=delete&id=<?php echo $avaliacao['id']; ?>" class="btn btn-danger">Excluir</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <?php
                                    $query_params = http_build_query([
                                        'status' => $status,
                                        'search' => $search
                                    ]);
                                    $query_string = !empty($query_params) ? '&' . $query_params : '';
                                    ?>
                                    
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=1<?php echo $query_string; ?>">
                                                <i class="fas fa-angle-double-left"></i>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo $query_string; ?>">
                                                <i class="fas fa-angle-left"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php
                                    $start_page = max(1, $page - 2);
                                    $end_page = min($total_pages, $page + 2);
                                    
                                    for ($i = $start_page; $i <= $end_page; $i++):
                                    ?>
                                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $i; ?><?php echo $query_string; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo $query_string; ?>">
                                                <i class="fas fa-angle-right"></i>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo $query_string; ?>">
                                                <i class="fas fa-angle-double-right"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>