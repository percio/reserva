<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    redirect('../login.php');
}

// Buscar dados do usuário
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Usuário não encontrado, fazer logout
    logout();
    redirect('../login.php');
}

// Estatísticas gerais
$stats = [
    'total_imoveis' => 0,
    'total_usuarios' => 0,
    'reservas_pendentes' => 0,
    'faturamento_mes' => 0
];

// Total de imóveis
$stmt = $pdo->prepare("SELECT COUNT(*) FROM imoveis");
$stmt->execute();
$stats['total_imoveis'] = $stmt->fetchColumn();

// Total de usuários
$stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE tipo = 'cliente'");
$stmt->execute();
$stats['total_usuarios'] = $stmt->fetchColumn();

// Reservas pendentes
$stmt = $pdo->prepare("SELECT COUNT(*) FROM reservas WHERE status = 'pendente'");
$stmt->execute();
$stats['reservas_pendentes'] = $stmt->fetchColumn();

// Faturamento do mês atual
$stmt = $pdo->prepare("
    SELECT SUM(valor_total) FROM reservas 
    WHERE MONTH(data_reserva) = MONTH(CURRENT_DATE()) 
    AND YEAR(data_reserva) = YEAR(CURRENT_DATE())
    AND status = 'confirmada'
");
$stmt->execute();
$stats['faturamento_mes'] = $stmt->fetchColumn() ?: 0;

// Últimas reservas
$stmt = $pdo->prepare("
    SELECT r.*, u.nome as usuario_nome, i.titulo as imovel_titulo 
    FROM reservas r
    JOIN usuarios u ON r.id_usuario = u.id
    JOIN imoveis i ON r.id_imovel = i.id
    ORDER BY r.data_reserva DESC
    LIMIT 10
");
$stmt->execute();
$ultimas_reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Imóveis mais reservados
$stmt = $pdo->prepare("
    SELECT i.id, i.titulo, i.cidade, i.estado, COUNT(r.id) as total_reservas
    FROM imoveis i
    LEFT JOIN reservas r ON i.id = r.id_imovel
    WHERE r.status = 'confirmada'
    GROUP BY i.id
    ORDER BY total_reservas DESC
    LIMIT 5
");
$stmt->execute();
$imoveis_populares = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Dashboard Administrativo</h2>
                </div>
                <div class="dashboard-user">
                    <img src="../img/admin-avatar.png" alt="Admin Avatar">
                    <div>
                        <h4><?php echo htmlspecialchars($user['nome']); ?></h4>
                        <p>Administrador</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-cards">
                <div class="stats-card primary">
                    <i class="fas fa-home"></i>
                    <div class="stats-info">
                        <h4>Total de Imóveis</h4>
                        <p><?php echo $stats['total_imoveis']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card success">
                    <i class="fas fa-users"></i>
                    <div class="stats-info">
                        <h4>Total de Usuários</h4>
                        <p><?php echo $stats['total_usuarios']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card warning">
                    <i class="fas fa-clock"></i>
                    <div class="stats-info">
                        <h4>Reservas Pendentes</h4>
                        <p><?php echo $stats['reservas_pendentes']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card danger">
                    <i class="fas fa-dollar-sign"></i>
                    <div class="stats-info">
                        <h4>Faturamento do Mês</h4>
                        <p>R$ <?php echo number_format($stats['faturamento_mes'], 2, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="dashboard-table">
                        <h3>Últimas Reservas</h3>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Imóvel</th>
                                        <th>Cliente</th>
                                        <th>Datas</th>
                                        <th>Valor</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ultimas_reservas as $reserva): ?>
                                    <tr>
                                        <td>#<?php echo $reserva['id']; ?></td>
                                        <td><?php echo htmlspecialchars($reserva['imovel_titulo']); ?></td>
                                        <td><?php echo htmlspecialchars($reserva['usuario_nome']); ?></td>
                                        <td>
                                            <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?> a 
                                            <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?>
                                        </td>
                                        <td>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></td>
                                        <td>
                                            <?php
                                            $status_class = '';
                                            $status_text = '';
                                            
                                            switch ($reserva['status']) {
                                                case 'pendente':
                                                    $status_class = 'bg-warning';
                                                    $status_text = 'Pendente';
                                                    break;
                                                case 'confirmada':
                                                    if (strtotime($reserva['data_saida']) < time()) {
                                                        $status_class = 'bg-secondary';
                                                        $status_text = 'Concluída';
                                                    } else {
                                                        $status_class = 'bg-success';
                                                        $status_text = 'Confirmada';
                                                    }
                                                    break;
                                                case 'cancelada':
                                                    $status_class = 'bg-danger';
                                                    $status_text = 'Cancelada';
                                                    break;
                                                default:
                                                    $status_class = 'bg-info';
                                                    $status_text = ucfirst($reserva['status']);
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                        </td>
                                        <td>
                                            <a href="reserva-detalhes.php?id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center mt-3">
                            <a href="reservas.php" class="btn btn-outline-primary">Ver Todas as Reservas</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="dashboard-table">
                        <h3>Imóveis Mais Populares</h3>
                        <ul class="list-group">
                            <?php foreach ($imoveis_populares as $imovel): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($imovel['titulo']); ?></strong>
                                    <p class="text-muted mb-0"><?php echo htmlspecialchars($imovel['cidade'] . ', ' . $imovel['estado']); ?></p>
                                </div>
                                <span class="badge bg-primary rounded-pill"><?php echo $imovel['total_reservas']; ?> reservas</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="text-center mt-3">
                            <a href="relatorios.php" class="btn btn-outline-primary">Ver Relatórios</a>
                        </div>
                    </div>
                    
                    <div class="dashboard-table mt-4">
                        <h3>Ações Rápidas</h3>
                        <div class="d-grid gap-2">
                            <a href="imovel-novo.php" class="btn btn-success">
                                <i class="fas fa-plus-circle"></i> Adicionar Imóvel
                            </a>
                            <a href="reservas.php?status=pendente" class="btn btn-warning">
                                <i class="fas fa-clock"></i> Reservas Pendentes
                            </a>
                            <a href="mensagens.php?status=novo" class="btn btn-info">
                                <i class="fas fa-envelope"></i> Mensagens Não Lidas
                            </a>
                            <a href="relatorios.php" class="btn btn-primary">
                                <i class="fas fa-chart-bar"></i> Gerar Relatórios
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>