<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Redirect to dashboard if logged in, otherwise to login page
if (isset($_SESSION['user_id']) && $_SESSION['user_tipo'] === 'admin') {
    redirect('dashboard.php');
} else {
    redirect('../login.php');
}