<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h3>Aluga<span>Fácil</span></h3>
                <p>Sua melhor opção para aluguel de temporada no litoral.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            <div class="col-md-4">
                <h4>Links Rápidos</h4>
                <ul>
                    <li><a href="index.php">Início</a></li>
                    <li><a href="imoveis.php">Imóveis</a></li>
                    <li><a href="sobre.php">Sobre Nós</a></li>
                    <li><a href="contato.php">Contato</a></li>
                    <li><a href="termos.php">Termos de Uso</a></li>
                    <li><a href="privacidade.php">Política de Privacidade</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h4>Contato</h4>
                <p><i class="fas fa-map-marker-alt"></i> Av. Beira Mar, 1000 - Caraguatatuba, SP</p>
                <p><i class="fas fa-phone"></i> (12) 3456-7890</p>
                <p><i class="fas fa-envelope"></i> contato@alugafacil.com.br</p>
            </div>
        </div>
        <div class="copyright">
            <p>&copy; <?php echo date('Y'); ?> AlugaFácil - Todos os direitos reservados.</p>
        </div>
    </div>
</footer>

