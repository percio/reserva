<?php
/**
 * Redirect para outra página
 *
 * @param string $url URL para redirecionar
 * @return void
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Limpa o texto de entrada
 *
 * @param string $text Texto a ser limpo
 * @return string Texto limpo
 */
function sanitize($text) {
    return htmlspecialchars(trim($text), ENT_QUOTES, 'UTF-8');
}

/**
 * Gera um token CSRF
 *
 * @return string Token CSRF
 */
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifica se o token CSRF é válido
 *
 * @param string $token Token a ser verificado
 * @return bool True se for válido, False caso contrário
 */
function is_csrf_valid($token) {
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Fazer logout do usuário
 *
 * @return void
 */
function logout() {
    // Limpar todas as variáveis de sessão
    $_SESSION = [];
    
    // Destruir o cookie da sessão
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Destruir a sessão
    session_destroy();
}

/**
 * Verificar se o usuário está logado
 *
 * @return bool True se estiver logado, False caso contrário
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Verificar se o usuário é administrador
 *
 * @return bool True se for admin, False caso contrário
 */
function is_admin() {
    return is_logged_in() && $_SESSION['user_tipo'] === 'admin';
}

/**
 * Formata um valor monetário
 *
 * @param float $value Valor a ser formatado
 * @return string Valor formatado como moeda brasileira
 */
function format_money($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

/**
 * Formata uma data
 *
 * @param string $date Data no formato Y-m-d
 * @param string $format Formato desejado
 * @return string Data formatada
 */
function format_date($date, $format = 'd/m/Y') {
    return date($format, strtotime($date));
}

/**
 * Calcula a diferença entre duas datas em dias
 *
 * @param string $start_date Data de início no formato Y-m-d
 * @param string $end_date Data de fim no formato Y-m-d
 * @return int Número de dias
 */
function date_diff_days($start_date, $end_date) {
    $start = new DateTime($start_date);
    $end = new DateTime($end_date);
    $diff = $start->diff($end);
    return $diff->days;
}

/**
 * Gera um slug a partir de um texto
 *
 * @param string $text Texto para gerar o slug
 * @return string Slug gerado
 */
function generate_slug($text) {
    // Remove acentos
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    
    if (empty($text)) {
        return 'n-a';
    }
    
    return $text;
}

/**
 * Upload de arquivo
 *
 * @param array $file Arquivo do $_FILES
 * @param string $destination Pasta de destino
 * @param array $allowed_types Tipos de arquivos permitidos
 * @param int $max_size Tamanho máximo em bytes
 * @return string|false Nome do arquivo se bem-sucedido, false em caso de erro
 */
function upload_file($file, $destination, $allowed_types = [], $max_size = 0) {
    // Verificar erros
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    // Verificar tamanho
    if ($max_size > 0 && $file['size'] > $max_size) {
        return false;
    }
    
    // Verificar tipo
    $file_info = pathinfo($file['name']);
    $extension = strtolower($file_info['extension']);
    
    if (!empty($allowed_types) && !in_array($extension, $allowed_types)) {
        return false;
    }
    
    // Gerar nome único
    $new_filename = uniqid() . '.' . $extension;
    $upload_path = rtrim($destination, '/') . '/' . $new_filename;
    
    // Mover arquivo
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return $new_filename;
    }
    
    return false;
}

/**
 * Envia email
 *
 * @param string $to Destinatário
 * @param string $subject Assunto
 * @param string $message Mensagem (pode ser HTML)
 * @param array $headers Cabeçalhos adicionais
 * @return bool True se enviado com sucesso, False caso contrário
 */
function send_email($to, $subject, $message, $headers = []) {
    // Cabeçalhos padrão
    $default_headers = [
        'From' => SITE_NAME . ' <' . ADMIN_EMAIL . '>',
        'Reply-To' => ADMIN_EMAIL,
        'MIME-Version' => '1.0',
        'Content-Type' => 'text/html; charset=UTF-8'
    ];
    
    // Mesclar cabeçalhos
    $headers = array_merge($default_headers, $headers);
    
    // Converter array de cabeçalhos para string
    $header_string = '';
    foreach ($headers as $key => $value) {
        $header_string .= "$key: $value\r\n";
    }
    
    // Enviar email
    return mail($to, $subject, $message, $header_string);
}

/**
 * Gera um resumo de texto
 *
 * @param string $text Texto completo
 * @param int $length Comprimento máximo
 * @return string Texto resumido
 */
function get_excerpt($text, $length = 150) {
    $text = strip_tags($text);
    
    if (strlen($text) <= $length) {
        return $text;
    }
    
    $text = substr($text, 0, $length);
    $text = substr($text, 0, strrpos($text, ' '));
    
    return $text . '...';
}

/**
 * Verifica disponibilidade do imóvel para as datas especificadas
 *
 * @param PDO $pdo Conexão PDO
 * @param int $property_id ID do imóvel
 * @param string $check_in Data de check-in (Y-m-d)
 * @param string $check_out Data de check-out (Y-m-d)
 * @param int $exclude_reservation_id ID da reserva a ser excluída da verificação (opcional)
 * @return bool True se disponível, False caso contrário
 */
function check_property_availability($pdo, $property_id, $check_in, $check_out, $exclude_reservation_id = null) {
    $params = [$property_id, $check_in, $check_out, $check_in, $check_out];
    
    $sql = "
        SELECT id FROM reservas 
        WHERE id_imovel = ? 
        AND status = 'confirmada'
        AND (
            (data_entrada <= ? AND data_saida >= ?) OR
            (data_entrada >= ? AND data_entrada < ?)
        )
    ";
    
    if ($exclude_reservation_id) {
        $sql .= " AND id != ?";
        $params[] = $exclude_reservation_id;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->rowCount() === 0;
}

/**
 * Calcula o valor total de uma reserva
 *
 * @param PDO $pdo Conexão PDO
 * @param int $property_id ID do imóvel
 * @param string $check_in Data de check-in (Y-m-d)
 * @param string $check_out Data de check-out (Y-m-d)
 * @return float Valor total da reserva
 */
function calculate_reservation_total($pdo, $property_id, $check_in, $check_out) {
    // Buscar valor da diária
    $stmt = $pdo->prepare("SELECT valor_diaria FROM imoveis WHERE id = ?");
    $stmt->execute([$property_id]);
    $property = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$property) {
        return 0;
    }
    
    // Calcular número de dias
    $days = date_diff_days($check_in, $check_out);
    
    // Calcular valor total
    return $property['valor_diaria'] * $days;
}

