<header>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <h1>Aluga<span>Fácil</span></h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Início</a></li>
                    <li class="nav-item"><a class="nav-link" href="imoveis.php">Imóveis</a></li>
                    <li class="nav-item"><a class="nav-link" href="sobre.php">Sobre Nós</a></li>
                    <li class="nav-item"><a class="nav-link" href="contato.php">Contato</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <?php if ($_SESSION['user_tipo'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="admin/dashboard.php">Painel Admin</a></li>
                                <?php elseif ($_SESSION['user_tipo'] === 'proprietario'): ?>
                                    <li><a class="dropdown-item" href="proprietario/dashboard.php">Painel do Proprietário</a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="dashboard.php">Minha Conta</a></li>
                                    <li><a class="dropdown-item" href="minhas-reservas.php">Minhas Reservas</a></li>
                                    <li><a class="dropdown-item" href="favoritos.php">Favoritos</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle btn btn-primary login-btn" href="#" id="loginDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Login/Cadastro
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="loginDropdown">
                                <li><a class="dropdown-item" href="login.php">Login</a></li>
                                <li><a class="dropdown-item" href="cadastro.php">Cadastro de Cliente</a></li>
                                <li><a class="dropdown-item" href="cadastro-proprietario.php">Cadastro de Proprietário</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>