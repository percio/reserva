<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

try {
    // Buscar imóveis em destaque
    $stmt = $pdo->prepare("
        SELECT id, titulo, descricao, cidade, estado, valor_diaria, quartos, banheiros, capacidade, foto_principal
        FROM imoveis
        WHERE destaque = 1 AND status = 'ativo'
        ORDER BY id DESC
        LIMIT 3
    ");
    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($properties);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao buscar imóveis em destaque']);
}

