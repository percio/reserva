document.addEventListener('DOMContentLoaded', function() {
    // Fetch and display featured properties
    fetchFeaturedProperties();
    
    // Mobile menu toggle for dashboard
    const menuToggle = document.querySelector('.menu-toggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    }
    
    // Initialize date pickers with validation
    const checkIn = document.querySelector('input[name="check_in"]');
    const checkOut = document.querySelector('input[name="check_out"]');
    
    if (checkIn && checkOut) {
        // Set minimum date as today
        const today = new Date().toISOString().split('T')[0];
        checkIn.min = today;
        
        checkIn.addEventListener('change', function() {
            // Set minimum check-out date as check-in date
            checkOut.min = checkIn.value;
            
            // Clear check-out if it's before check-in
            if (checkOut.value && checkOut.value < checkIn.value) {
                checkOut.value = '';
            }
        });
    }
    
    // Form validations
    const forms = document.querySelectorAll('.needs-validation');
    if (forms.length > 0) {
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }
});

// Function to fetch featured properties from the server
function fetchFeaturedProperties() {
    const container = document.getElementById('featured-properties-container');
    if (!container) return;
    
    // Fetch properties using AJAX
    fetch('api/get_featured_properties.php')
        .then(response => response.json())
        .then(properties => {
            if (properties.length === 0) {
                container.innerHTML = '<div class="col-12 text-center"><p>Não há imóveis em destaque no momento.</p></div>';
                return;
            }
            
            let html = '';
            properties.forEach(property => {
                html += `
                <div class="col-md-4 mb-4">
                    <div class="property-card">
                        <div class="property-image" style="background-image: url('${property.foto_principal}')"></div>
                        <div class="property-info">
                            <h3>${property.titulo}</h3>
                            <p><i class="fas fa-map-marker-alt"></i> ${property.cidade}, ${property.estado}</p>
                            <div class="price">R$ ${property.valor_diaria.toFixed(2)} / noite</div>
                            <div class="property-features">
                                <span><i class="fas fa-bed"></i> ${property.quartos} quartos</span>
                                <span><i class="fas fa-bath"></i> ${property.banheiros} banheiros</span>
                                <span><i class="fas fa-users"></i> ${property.capacidade} pessoas</span>
                            </div>
                            <a href="imovel.php?id=${property.id}" class="btn btn-primary w-100">Ver Detalhes</a>
                        </div>
                    </div>
                </div>`;
            });
            
            container.innerHTML = html;
        })
        .catch(error => {
            console.error('Erro ao carregar imóveis:', error);
            container.innerHTML = '<div class="col-12 text-center"><p>Erro ao carregar imóveis. Por favor, tente novamente mais tarde.</p></div>';
        });
}

