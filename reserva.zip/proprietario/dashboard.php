<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Buscar dados do usuário
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Usuário não encontrado, fazer logout
    logout();
    redirect('../login.php');
}

// Buscar estatísticas do proprietário
$stats = [
    'total_imoveis' => 0,
    'total_reservas' => 0,
    'reservas_pendentes' => 0,
    'faturamento_total' => 0
];

// Total de imóveis do proprietário
$stmt = $pdo->prepare("SELECT COUNT(*) FROM imoveis WHERE id_proprietario = ?");
$stmt->execute([$user_id]);
$stats['total_imoveis'] = $stmt->fetchColumn();

// Total de reservas
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM reservas r
    JOIN imoveis i ON r.id_imovel = i.id
    WHERE i.id_proprietario = ?
");
$stmt->execute([$user_id]);
$stats['total_reservas'] = $stmt->fetchColumn();

// Reservas pendentes
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM reservas r
    JOIN imoveis i ON r.id_imovel = i.id
    WHERE i.id_proprietario = ? AND r.status = 'pendente'
");
$stmt->execute([$user_id]);
$stats['reservas_pendentes'] = $stmt->fetchColumn();

// Faturamento total
$stmt = $pdo->prepare("
    SELECT SUM(r.valor_total) FROM reservas r
    JOIN imoveis i ON r.id_imovel = i.id
    WHERE i.id_proprietario = ? AND r.status = 'confirmada'
");
$stmt->execute([$user_id]);
$stats['faturamento_total'] = $stmt->fetchColumn() ?: 0;

// Buscar imóveis do proprietário
$stmt = $pdo->prepare("
    SELECT * FROM imoveis 
    WHERE id_proprietario = ? 
    ORDER BY id DESC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$imoveis = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar últimas reservas dos imóveis do proprietário
$stmt = $pdo->prepare("
    SELECT r.*, u.nome as usuario_nome, i.titulo as imovel_titulo, i.foto_principal
    FROM reservas r
    JOIN usuarios u ON r.id_usuario = u.id
    JOIN imoveis i ON r.id_imovel = i.id
    WHERE i.id_proprietario = ?
    ORDER BY r.data_reserva DESC
    LIMIT 5
");
$stmt->execute([$user_id]);
$ultimas_reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard do Proprietário - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Dashboard do Proprietário</h2>
                </div>
                <div class="dashboard-user">
                    <img src="../img/user-avatar.png" alt="Avatar">
                    <div>
                        <h4><?php echo htmlspecialchars($user['nome']); ?></h4>
                        <p><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-cards">
                <div class="stats-card primary">
                    <i class="fas fa-home"></i>
                    <div class="stats-info">
                        <h4>Meus Imóveis</h4>
                        <p><?php echo $stats['total_imoveis']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card success">
                    <i class="fas fa-calendar-check"></i>
                    <div class="stats-info">
                        <h4>Reservas Totais</h4>
                        <p><?php echo $stats['total_reservas']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card warning">
                    <i class="fas fa-clock"></i>
                    <div class="stats-info">
                        <h4>Reservas Pendentes</h4>
                        <p><?php echo $stats['reservas_pendentes']; ?></p>
                    </div>
                </div>
                
                <div class="stats-card danger">
                    <i class="fas fa-dollar-sign"></i>
                    <div class="stats-info">
                        <h4>Faturamento Total</h4>
                        <p>R$ <?php echo number_format($stats['faturamento_total'], 2, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="dashboard-table">
                        <h3>Meus Imóveis</h3>
                        
                        <?php if (empty($imoveis)): ?>
                            <div class="alert alert-info">
                                Você ainda não cadastrou nenhum imóvel. <a href="imovel-novo.php">Cadastrar agora</a>.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Imóvel</th>
                                            <th>Valor/Diária</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($imoveis as $imovel): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo htmlspecialchars($imovel['foto_principal']); ?>" alt="<?php echo htmlspecialchars($imovel['titulo']); ?>" width="50" height="50" class="rounded me-2">
                                                    <?php echo htmlspecialchars($imovel['titulo']); ?>
                                                </div>
                                            </td>
                                            <td>R$ <?php echo number_format($imovel['valor_diaria'], 2, ',', '.'); ?></td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch ($imovel['status']) {
                                                    case 'ativo':
                                                        $status_class = 'bg-success';
                                                        break;
                                                    case 'inativo':
                                                        $status_class = 'bg-danger';
                                                        break;
                                                    case 'manutencao':
                                                        $status_class = 'bg-warning';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $status_class; ?>">
                                                    <?php echo ucfirst($imovel['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="imovel-editar.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="imovel-detalhes.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="text-center mt-3">
                                <a href="imoveis.php" class="btn btn-outline-primary">Ver Todos os Imóveis</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="dashboard-table">
                        <h3>Últimas Reservas</h3>
                        
                        <?php if (empty($ultimas_reservas)): ?>
                            <div class="alert alert-info">
                                Ainda não há reservas para seus imóveis.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Cliente</th>
                                            <th>Imóvel</th>
                                            <th>Data</th>
                                            <th>Status</th>
                                            <th>Valor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($ultimas_reservas as $reserva): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($reserva['usuario_nome']); ?></td>
                                            <td><?php echo htmlspecialchars($reserva['imovel_titulo']); ?></td>
                                            <td>
                                                <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?> a 
                                                <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?>
                                            </td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch ($reserva['status']) {
                                                    case 'pendente':
                                                        $status_class = 'bg-warning';
                                                        break;
                                                    case 'confirmada':
                                                        $status_class = 'bg-success';
                                                        break;
                                                    case 'cancelada':
                                                        $status_class = 'bg-danger';
                                                        break;
                                                    case 'concluida':
                                                        $status_class = 'bg-secondary';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $status_class; ?>">
                                                    <?php echo ucfirst($reserva['status']); ?>
                                                </span>
                                            </td>
                                            <td>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="text-center mt-3">
                                <a href="reservas.php" class="btn btn-outline-primary">Ver Todas as Reservas</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-table mt-4">
                <h3>Ações Rápidas</h3>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <a href="imovel-novo.php" class="btn btn-success w-100">
                            <i class="fas fa-plus-circle"></i> Adicionar Imóvel
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="reservas.php?status=pendente" class="btn btn-warning w-100">
                            <i class="fas fa-clock"></i> Reservas Pendentes
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="mensagens.php" class="btn btn-info w-100">
                            <i class="fas fa-envelope"></i> Mensagens
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="relatorio.php" class="btn btn-primary w-100">
                            <i class="fas fa-chart-bar"></i> Relatórios
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>