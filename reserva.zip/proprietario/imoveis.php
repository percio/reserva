<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Processar ações
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    // Verificar se o imóvel pertence ao proprietário
    $stmt = $pdo->prepare("SELECT id FROM imoveis WHERE id = ? AND id_proprietario = ?");
    $stmt->execute([$id, $user_id]);
    
    if ($stmt->rowCount() === 0) {
        $_SESSION['error'] = "Operação não permitida";
        redirect('imoveis.php');
    }
    
    switch ($action) {
        case 'activate':
            try {
                $stmt = $pdo->prepare("UPDATE imoveis SET status = 'ativo' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Imóvel ativado com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao ativar imóvel: " . $e->getMessage();
            }
            break;
            
        case 'deactivate':
            try {
                $stmt = $pdo->prepare("UPDATE imoveis SET status = 'inativo' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Imóvel desativado com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao desativar imóvel: " . $e->getMessage();
            }
            break;
            
        case 'maintenance':
            try {
                $stmt = $pdo->prepare("UPDATE imoveis SET status = 'manutencao' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Imóvel colocado em manutenção!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao atualizar status: " . $e->getMessage();
            }
            break;
            
        case 'delete':
            try {
                // Verificar se o imóvel tem reservas
                $stmt = $pdo->prepare("SELECT id FROM reservas WHERE id_imovel = ? LIMIT 1");
                $stmt->execute([$id]);
                
                if ($stmt->rowCount() > 0) {
                    $_SESSION['error'] = "Não é possível excluir imóvel com reservas!";
                    redirect('imoveis.php');
                }
                
                $pdo->beginTransaction();
                
                // Excluir dados relacionados
                $pdo->prepare("DELETE FROM caracteristicas_imoveis WHERE id_imovel = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM imagens_imoveis WHERE id_imovel = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM regras_imoveis WHERE id_imovel = ?")->execute([$id]);
                
                // Excluir o imóvel
                $pdo->prepare("DELETE FROM imoveis WHERE id = ?")->execute([$id]);
                
                $pdo->commit();
                $_SESSION['success'] = "Imóvel excluído com sucesso!";
            } catch (PDOException $e) {
                $pdo->rollBack();
                $_SESSION['error'] = "Erro ao excluir imóvel: " . $e->getMessage();
            }
            break;
    }
    
    redirect('imoveis.php');
}

// Paginação
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Filtros
$status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Construir consulta
$where = "WHERE id_proprietario = ?";
$params = [$_SESSION['user_id']];

if (!empty($status)) {
    $where .= " AND status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $where .= " AND (titulo LIKE ? OR cidade LIKE ? OR descricao LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Total de registros
$stmt = $pdo->prepare("SELECT COUNT(*) FROM imoveis $where");
$stmt->execute($params);
$total_imoveis = $stmt->fetchColumn();
$total_pages = ceil($total_imoveis / $limit);

// Buscar imóveis
$sql = "SELECT * FROM imoveis $where ORDER BY id DESC LIMIT ?, ?";
$params[] = $offset;
$params[] = $limit;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$imoveis = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Imóveis - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Meus Imóveis</h2>
                </div>
                <div class="dashboard-actions">
                    <a href="imovel-novo.php" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Adicionar Imóvel
                    </a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-filters">
                <div class="card">
                    <div class="card-body">
                        <form action="imoveis.php" method="GET" class="row g-3">
                            <div class="col-md-4">
                                <select name="status" class="form-select">
                                    <option value="">Todos os status</option>
                                    <option value="ativo" <?php echo $status === 'ativo' ? 'selected' : ''; ?>>Ativo</option>
                                    <option value="inativo" <?php echo $status === 'inativo' ? 'selected' : ''; ?>>Inativo</option>
                                    <option value="manutencao" <?php echo $status === 'manutencao' ? 'selected' : ''; ?>>Em Manutenção</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="search" class="form-control" placeholder="Buscar por título, cidade ou descrição" value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-table">
                <div class="card">
                    <div class="card-body">
                        <?php if (empty($imoveis)): ?>
                            <div class="alert alert-info">
                                <p>Nenhum imóvel encontrado. <a href="imovel-novo.php">Clique aqui</a> para adicionar seu primeiro imóvel.</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Foto</th>
                                            <th>Título</th>
                                            <th>Localização</th>
                                            <th>Valor/Diária</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($imoveis as $imovel): ?>
                                            <tr>
                                                <td>
                                                    <img src="<?php echo htmlspecialchars($imovel['foto_principal']); ?>" 
                                                        alt="<?php echo htmlspecialchars($imovel['titulo']); ?>" 
                                                        width="60" height="60" class="rounded">
                                                </td>
                                                <td><?php echo htmlspecialchars($imovel['titulo']); ?></td>
                                                <td><?php echo htmlspecialchars($imovel['cidade'] . ', ' . $imovel['estado']); ?></td>
                                                <td>R$ <?php echo number_format($imovel['valor_diaria'], 2, ',', '.'); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_class = '';
                                                    switch ($imovel['status']) {
                                                        case 'ativo':
                                                            $status_class = 'bg-success';
                                                            break;
                                                        case 'inativo':
                                                            $status_class = 'bg-danger';
                                                            break;
                                                        case 'manutencao':
                                                            $status_class = 'bg-warning';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo ucfirst($imovel['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="imovel-editar.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-primary" title="Editar">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="imovel-detalhes.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-info" title="Detalhes">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <a href="imovel-fotos.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-success" title="Gerenciar Fotos">
                                                            <i class="fas fa-images"></i>
                                                        </a>
                                                        <a href="imovel-reservas.php?id=<?php echo $imovel['id']; ?>" class="btn btn-sm btn-secondary" title="Ver Reservas">
                                                            <i class="fas fa-calendar-check"></i>
                                                        </a>
                                                        
                                                        <button type="button" class="btn btn-sm btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class="fas fa-cog"></i>
                                                        </button>
                                                        <ul class="dropdown-menu">
                                                            <?php if ($imovel['status'] !== 'ativo'): ?>
                                                                <li><a class="dropdown-item" href="imoveis.php?action=activate&id=<?php echo $imovel['id']; ?>">Ativar</a></li>
                                                            <?php endif; ?>
                                                            
                                                            <?php if ($imovel['status'] !== 'inativo'): ?>
                                                                <li><a class="dropdown-item" href="imoveis.php?action=deactivate&id=<?php echo $imovel['id']; ?>">Desativar</a></li>
                                                            <?php endif; ?>
                                                            
                                                            <?php if ($imovel['status'] !== 'manutencao'): ?>
                                                                <li><a class="dropdown-item" href="imoveis.php?action=maintenance&id=<?php echo $imovel['id']; ?>">Em Manutenção</a></li>
                                                            <?php endif; ?>
                                                            
                                                            <li><hr class="dropdown-divider"></li>
                                                            <li><a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $imovel['id']; ?>">Excluir</a></li>
                                                        </ul>
                                                    </div>
                                                    
                                                    <!-- Delete Modal -->
                                                    <div class="modal fade" id="deleteModal<?php echo $imovel['id']; ?>" tabindex="-1" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Tem certeza que deseja excluir o imóvel "<?php echo htmlspecialchars($imovel['titulo']); ?>"?</p>
                                                                    <p class="text-danger">Esta ação não pode ser desfeita!</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                    <a href="imoveis.php?action=delete&id=<?php echo $imovel['id']; ?>" class="btn btn-danger">Excluir</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-center">
                                        <?php if ($page > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=1<?php echo !empty($status) ? '&status=' . $status : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                    <i class="fas fa-angle-double-left"></i>
                                                </a>
                                            </li>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($status) ? '&status=' . $status : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                    <i class="fas fa-angle-left"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);
                                        
                                        for ($i = $start_page; $i <= $end_page; $i++):
                                        ?>
                                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($status) ? '&status=' . $status : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endfor; ?>
                                        
                                        <?php if ($page < $total_pages): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($status) ? '&status=' . $status : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                    <i class="fas fa-angle-right"></i>
                                                </a>
                                            </li>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo !empty($status) ? '&status=' . $status : ''; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                                                    <i class="fas fa-angle-double-right"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>