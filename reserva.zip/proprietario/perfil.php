<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];

// Buscar dados do usuário
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$user_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    // Usuário não encontrado, fazer logout
    logout();
    redirect('../login.php');
}

$errors = [];
$success = false;

// Processar formulário de atualização de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_perfil'])) {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
    
    // Validações
    if (empty($nome)) {
        $errors[] = 'O nome é obrigatório';
    }
    
    if (empty($email)) {
        $errors[] = 'O email é obrigatório';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'O email informado é inválido';
    } else {
        // Verificar se o email já está sendo usado por outro usuário
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ? AND id <> ?");
        $stmt->execute([$email, $user_id]);
        if ($stmt->rowCount() > 0) {
            $errors[] = 'Este email já está sendo usado por outro usuário';
        }
    }
    
    if (empty($telefone)) {
        $errors[] = 'O telefone é obrigatório';
    }
    
    // Processar avatar, se enviado
    $avatar = $usuario['avatar'];
    if (!empty($_FILES['avatar']['name'])) {
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        if (!in_array($_FILES['avatar']['type'], $allowed_types)) {
            $errors[] = 'Formato de imagem não permitido. Use JPG, PNG ou GIF.';
        } elseif ($_FILES['avatar']['size'] > $max_size) {
            $errors[] = 'A imagem deve ter no máximo 2MB.';
        } else {
            $upload_dir = '../uploads/avatares/';
            
            // Criar diretório se não existir
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
            $new_filename = 'avatar_' . $user_id . '_' . time() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                $avatar = $upload_path;
            } else {
                $errors[] = 'Erro ao fazer upload da imagem.';
            }
        }
    }
    
    // Se não houver erros, atualizar o perfil
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE usuarios 
                SET nome = ?, email = ?, telefone = ?, avatar = ? 
                WHERE id = ?
            ");
            $stmt->execute([$nome, $email, $telefone, $avatar, $user_id]);
            
            $success = true;
            
            // Atualizar dados da sessão
            $_SESSION['user_name'] = $nome;
            $_SESSION['user_email'] = $email;
            
            // Recarregar dados do usuário
            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
            $stmt->execute([$user_id]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $errors[] = 'Erro ao atualizar perfil: ' . $e->getMessage();
        }
    }
}

// Processar alteração de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['alterar_senha'])) {
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    
    // Validações
    if (empty($senha_atual)) {
        $errors[] = 'A senha atual é obrigatória';
    } elseif (!password_verify($senha_atual, $usuario['senha'])) {
        $errors[] = 'A senha atual está incorreta';
    }
    
    if (empty($nova_senha)) {
        $errors[] = 'A nova senha é obrigatória';
    } elseif (strlen($nova_senha) < 6) {
        $errors[] = 'A nova senha deve ter pelo menos 6 caracteres';
    }
    
    if ($nova_senha !== $confirmar_senha) {
        $errors[] = 'A confirmação da nova senha não confere';
    }
    
    // Se não houver erros, alterar a senha
    if (empty($errors)) {
        try {
            $hashed_password = password_hash($nova_senha, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("
                UPDATE usuarios 
                SET senha = ? 
                WHERE id = ?
            ");
            $stmt->execute([$hashed_password, $user_id]);
            
            $success = true;
        } catch (PDOException $e) {
            $errors[] = 'Erro ao alterar senha: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Meu Perfil</h2>
                </div>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Suas informações foram atualizadas com sucesso!
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informações Pessoais</h5>
                        </div>
                        <div class="card-body">
                            <form action="perfil.php" method="POST" enctype="multipart/form-data">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="nome" class="form-label">Nome Completo</label>
                                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($usuario['nome']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="telefone" class="form-label">Telefone</label>
                                            <input type="tel" class="form-control" id="telefone" name="telefone" value="<?php echo htmlspecialchars($usuario['telefone']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="avatar" class="form-label">Avatar</label>
                                            <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*">
                                            <div class="form-text">Deixe em branco para manter o avatar atual.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Data de Cadastro</label>
                                    <input type="text" class="form-control" value="<?php echo date('d/m/Y', strtotime($usuario['data_cadastro'])); ?>" readonly>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="atualizar_perfil" class="btn btn-primary">
                                        <i class="fas fa-save"></i> Salvar Alterações
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Alterar Senha</h5>
                        </div>
                        <div class="card-body">
                            <form action="perfil.php" method="POST">
                                <div class="mb-3">
                                    <label for="senha_atual" class="form-label">Senha Atual</label>
                                    <input type="password" class="form-control" id="senha_atual" name="senha_atual" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nova_senha" class="form-label">Nova Senha</label>
                                    <input type="password" class="form-control" id="nova_senha" name="nova_senha" required minlength="6">
                                    <div class="form-text">A senha deve ter pelo menos 6 caracteres.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="confirmar_senha" class="form-label">Confirmar Nova Senha</label>
                                    <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" required>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="alterar_senha" class="btn btn-warning">
                                        <i class="fas fa-key"></i> Alterar Senha
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Seu Perfil</h5>
                        </div>
                        <div class="card-body text-center">
                            <?php if (!empty($usuario['avatar'])): ?>
                                <img src="<?php echo htmlspecialchars($usuario['avatar']); ?>" alt="Avatar" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <?php else: ?>
                                <div class="avatar-placeholder mb-3 mx-auto">
                                    <i class="fas fa-user fa-5x"></i>
                                </div>
                            <?php endif; ?>
                            
                            <h4><?php echo htmlspecialchars($usuario['nome']); ?></h4>
                            <p class="text-muted"><?php echo htmlspecialchars($usuario['email']); ?></p>
                            <p class="badge bg-primary">Proprietário</p>
                            
                            <?php if ($usuario['status'] === 'ativo'): ?>
                                <p class="badge bg-success">Ativo</p>
                            <?php elseif ($usuario['status'] === 'pendente'): ?>
                                <p class="badge bg-warning">Pendente</p>
                            <?php else: ?>
                                <p class="badge bg-danger">Inativo</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Dicas de Segurança</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <i class="fas fa-lock text-primary me-2"></i> Use senhas fortes com pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas, números e símbolos.
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-sync text-primary me-2"></i> Troque sua senha regularmente a cada 3 meses.
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-fingerprint text-primary me-2"></i> Nunca compartilhe suas credenciais de acesso com outras pessoas.
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-shield-alt text-primary me-2"></i> Verifique regularmente suas atividades e reservas para detectar qualquer comportamento suspeito.
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        // Máscara para telefone
        document.getElementById('telefone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) value = value.substring(0, 11);
            
            if (value.length > 6) {
                value = `(${value.substring(0, 2)}) ${value.substring(2, 7)}-${value.substring(7)}`;
            } else if (value.length > 2) {
                value = `(${value.substring(0, 2)}) ${value.substring(2)}`;
            }
            
            e.target.value = value;
        });
        
        // Validar confirmação de senha
        document.getElementById('confirmar_senha').addEventListener('input', function() {
            const novaSenha = document.getElementById('nova_senha').value;
            const confirmarSenha = this.value;
            
            if (novaSenha !== confirmarSenha) {
                this.setCustomValidity('As senhas não coincidem');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>