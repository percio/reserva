<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Processar solicitação de relatório
$report_type = isset($_GET['type']) ? $_GET['type'] : '';
$imovel_id = isset($_GET['imovel_id']) ? intval($_GET['imovel_id']) : 0;
$data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : date('Y-m-01'); // Primeiro dia do mês atual
$data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : date('Y-m-t'); // Último dia do mês atual

// Dados padrão
$report_data = [];
$report_title = '';

// Verificar se o imóvel pertence ao proprietário
if ($imovel_id > 0) {
    $stmt = $pdo->prepare("SELECT id FROM imoveis WHERE id = ? AND id_proprietario = ?");
    $stmt->execute([$imovel_id, $_SESSION['user_id']]);
    
    if ($stmt->rowCount() === 0) {
        $imovel_id = 0;
    }
}

// Buscar imóveis do proprietário para o filtro
$stmt = $pdo->prepare("SELECT id, titulo FROM imoveis WHERE id_proprietario = ? ORDER BY titulo");
$stmt->execute([$_SESSION['user_id']]);
$imoveis_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Gerar relatório conforme o tipo selecionado
if (!empty($report_type)) {
    switch ($report_type) {
        case 'ocupacao':
            $report_title = 'Relatório de Ocupação';
            
            // Construir WHERE com base nos filtros
            $where = "WHERE i.id_proprietario = ?";
            $params = [$_SESSION['user_id']];
            
            if ($imovel_id > 0) {
                $where .= " AND i.id = ?";
                $params[] = $imovel_id;
            }
            
            // Adicionar filtro de data
            $where .= " AND ((r.data_entrada BETWEEN ? AND ?) OR (r.data_saida BETWEEN ? AND ?))";
            $params[] = $data_inicio;
            $params[] = $data_fim;
            $params[] = $data_inicio;
            $params[] = $data_fim;
            
            // Buscar reservas no período selecionado
            $sql = "
                SELECT i.id, i.titulo, i.cidade, i.estado, 
                       r.data_entrada, r.data_saida, r.status, r.valor_total,
                       u.nome as cliente_nome
                FROM imoveis i
                JOIN reservas r ON i.id = r.id_imovel
                JOIN usuarios u ON r.id_usuario = u.id
                $where
                ORDER BY i.titulo, r.data_entrada
            ";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Agrupar por imóvel para calcular totais
            $grouped_data = [];
            foreach ($report_data as $item) {
                if (!isset($grouped_data[$item['id']])) {
                    $grouped_data[$item['id']] = [
                        'id' => $item['id'],
                        'titulo' => $item['titulo'],
                        'cidade' => $item['cidade'],
                        'estado' => $item['estado'],
                        'total_reservas' => 0,
                        'total_valor' => 0,
                        'reservas' => []
                    ];
                }
                
                if ($item['status'] !== 'cancelada') {
                    $grouped_data[$item['id']]['total_reservas']++;
                    $grouped_data[$item['id']]['total_valor'] += $item['valor_total'];
                }
                
                $grouped_data[$item['id']]['reservas'][] = $item;
            }
            
            $report_data = array_values($grouped_data);
            break;
            
        case 'faturamento':
            $report_title = 'Relatório de Faturamento';
            
            // Construir WHERE com base nos filtros
            $where = "WHERE i.id_proprietario = ? AND r.status = 'confirmada'";
            $params = [$_SESSION['user_id']];
            
            if ($imovel_id > 0) {
                $where .= " AND i.id = ?";
                $params[] = $imovel_id;
            }
            
            // Adicionar filtro de data
            $where .= " AND r.data_entrada BETWEEN ? AND ?";
            $params[] = $data_inicio;
            $params[] = $data_fim;
            
            // Buscar faturamento mensal
            $sql = "
                SELECT 
                    DATE_FORMAT(r.data_entrada, '%Y-%m') as mes,
                    COUNT(*) as total_reservas,
                    SUM(r.valor_total) as receita_total,
                    MIN(i.valor_diaria) as valor_min,
                    MAX(i.valor_diaria) as valor_max,
                    AVG(i.valor_diaria) as valor_medio
                FROM imoveis i
                JOIN reservas r ON i.id = r.id_imovel
                $where
                GROUP BY DATE_FORMAT(r.data_entrada, '%Y-%m')
                ORDER BY mes
            ";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Preparar dados para o gráfico
            $labels = [];
            $values = [];
            
            foreach ($report_data as $item) {
                $month_year = explode('-', $item['mes']);
                $month_name = date('M', mktime(0, 0, 0, $month_year[1], 1));
                $labels[] = $month_name . '/' . $month_year[0];
                $values[] = $item['receita_total'];
            }
            break;
            
        case 'imoveis':
            $report_title = 'Desempenho dos Imóveis';
            
            // Construir WHERE com base nos filtros
            $where = "WHERE i.id_proprietario = ? AND r.status = 'confirmada'";
            $params = [$_SESSION['user_id']];
            
            if ($imovel_id > 0) {
                $where .= " AND i.id = ?";
                $params[] = $imovel_id;
            }
            
            // Adicionar filtro de data
            $where .= " AND r.data_entrada BETWEEN ? AND ?";
            $params[] = $data_inicio;
            $params[] = $data_fim;
            
            // Buscar desempenho dos imóveis
            $sql = "
                SELECT 
                    i.id, i.titulo, i.cidade, i.estado, i.valor_diaria,
                    COUNT(r.id) as total_reservas,
                    SUM(r.valor_total) as receita_total,
                    SUM(DATEDIFF(r.data_saida, r.data_entrada)) as total_diarias
                FROM imoveis i
                LEFT JOIN reservas r ON i.id = r.id_imovel
                $where
                GROUP BY i.id
                ORDER BY receita_total DESC
            ";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calcular métricas adicionais
            foreach ($report_data as &$item) {
                $item['ocupacao'] = $item['total_diarias'] > 0 ? 
                    round(($item['total_diarias'] / (strtotime($data_fim) - strtotime($data_inicio)) * 86400) * 100, 2) : 0;
                
                $item['media_diaria'] = $item['total_diarias'] > 0 ? 
                    $item['receita_total'] / $item['total_diarias'] : 0;
            }
            break;
            
        case 'clientes':
            $report_title = 'Relatório de Clientes';
            
            // Construir WHERE com base nos filtros
            $where = "WHERE i.id_proprietario = ? AND r.status = 'confirmada'";
            $params = [$_SESSION['user_id']];
            
            if ($imovel_id > 0) {
                $where .= " AND i.id = ?";
                $params[] = $imovel_id;
            }
            
            // Adicionar filtro de data
            $where .= " AND r.data_entrada BETWEEN ? AND ?";
            $params[] = $data_inicio;
            $params[] = $data_fim;
            
            // Buscar dados dos clientes que realizaram reservas
            $sql = "
                SELECT 
                    u.id, u.nome, u.email,
                    COUNT(r.id) as total_reservas,
                    SUM(r.valor_total) as valor_total,
                    MIN(r.data_entrada) as primeira_reserva,
                    MAX(r.data_entrada) as ultima_reserva
                FROM usuarios u
                JOIN reservas r ON u.id = r.id_usuario
                JOIN imoveis i ON r.id_imovel = i.id
                $where
                GROUP BY u.id
                ORDER BY total_reservas DESC, valor_total DESC
            ";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Relatórios</h2>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form action="relatorio.php" method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label for="type" class="form-label">Tipo de Relatório</label>
                            <select name="type" id="type" class="form-select" required>
                                <option value="">Selecione um relatório</option>
                                <option value="ocupacao" <?php echo $report_type === 'ocupacao' ? 'selected' : ''; ?>>Ocupação dos Imóveis</option>
                                <option value="faturamento" <?php echo $report_type === 'faturamento' ? 'selected' : ''; ?>>Faturamento Mensal</option>
                                <option value="imoveis" <?php echo $report_type === 'imoveis' ? 'selected' : ''; ?>>Desempenho dos Imóveis</option>
                                <option value="clientes" <?php echo $report_type === 'clientes' ? 'selected' : ''; ?>>Análise de Clientes</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="imovel_id" class="form-label">Imóvel</label>
                            <select name="imovel_id" id="imovel_id" class="form-select">
                                <option value="0">Todos os imóveis</option>
                                <?php foreach ($imoveis_list as $imovel): ?>
                                    <option value="<?php echo $imovel['id']; ?>" <?php echo $imovel_id == $imovel['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($imovel['titulo']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?php echo $data_inicio; ?>" required>
                        </div>
                        <div class="col-md-2">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?php echo $data_fim; ?>" required>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Gerar Relatório</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <?php if (!empty($report_type) && !empty($report_data)): ?>
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo $report_title; ?></h5>
                        <div>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="window.print()">
                                <i class="fas fa-print"></i> Imprimir
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success" id="exportExcel">
                                <i class="fas fa-file-excel"></i> Exportar Excel
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger" id="exportPDF">
                                <i class="fas fa-file-pdf"></i> Exportar PDF
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($report_type === 'ocupacao'): ?>
                            <div class="mb-4">
                                <h6>Período: <?php echo date('d/m/Y', strtotime($data_inicio)); ?> a <?php echo date('d/m/Y', strtotime($data_fim)); ?></h6>
                            </div>
                            
                            <?php if (empty($report_data)): ?>
                                <div class="alert alert-info">
                                    Não foram encontradas reservas para o período selecionado.
                                </div>
                            <?php else: ?>
                                <?php foreach ($report_data as $imovel): ?>
                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <h5 class="mb-0"><?php echo htmlspecialchars($imovel['titulo']); ?></h5>
                                            <small><?php echo htmlspecialchars($imovel['cidade'] . ', ' . $imovel['estado']); ?></small>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <p><strong>Total de Reservas:</strong> <?php echo $imovel['total_reservas']; ?></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <p><strong>Faturamento:</strong> R$ <?php echo number_format($imovel['total_valor'], 2, ',', '.'); ?></p>
                                                </div>
                                            </div>
                                            
                                            <h6 class="mt-3 mb-3">Reservas no Período:</h6>
                                            <div class="table-responsive">
                                                <table class="table table-sm table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Cliente</th>
                                                            <th>Check-in</th>
                                                            <th>Check-out</th>
                                                            <th>Valor</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($imovel['reservas'] as $reserva): ?>
                                                            <tr>
                                                                <td><?php echo htmlspecialchars($reserva['cliente_nome']); ?></td>
                                                                <td><?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?></td>
                                                                <td><?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?></td>
                                                                <td>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></td>
                                                                <td>
                                                                    <?php
                                                                    $status_class = '';
                                                                    switch ($reserva['status']) {
                                                                        case 'pendente':
                                                                            $status_class = 'bg-warning';
                                                                            break;
                                                                        case 'confirmada':
                                                                            $status_class = 'bg-success';
                                                                            break;
                                                                        case 'cancelada':
                                                                            $status_class = 'bg-danger';
                                                                            break;
                                                                        case 'concluida':
                                                                            $status_class = 'bg-secondary';
                                                                            break;
                                                                    }
                                                                    ?>
                                                                    <span class="badge <?php echo $status_class; ?>">
                                                                        <?php echo ucfirst($reserva['status']); ?>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php elseif ($report_type === 'faturamento'): ?>
                            <div class="chart-container mb-4">
                                <canvas id="faturamentoChart" height="100"></canvas>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Mês</th>
                                            <th>Total de Reservas</th>
                                            <th>Receita Total</th>
                                            <th>Valor Médio Diária</th>
                                            <th>Valor Mínimo Diária</th>
                                            <th>Valor Máximo Diária</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $item): ?>
                                            <tr>
                                                <?php
                                                $month_year = explode('-', $item['mes']);
                                                $month_name = date('F', mktime(0, 0, 0, $month_year[1], 1));
                                                ?>
                                                <td><?php echo $month_name . ' ' . $month_year[0]; ?></td>
                                                <td><?php echo $item['total_reservas']; ?></td>
                                                <td>R$ <?php echo number_format($item['receita_total'], 2, ',', '.'); ?></td>
                                                <td>R$ <?php echo number_format($item['valor_medio'], 2, ',', '.'); ?></td>
                                                <td>R$ <?php echo number_format($item['valor_min'], 2, ',', '.'); ?></td>
                                                <td>R$ <?php echo number_format($item['valor_max'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    // Faturamento chart
                                    const faturamentoCtx = document.getElementById('faturamentoChart');
                                    new Chart(faturamentoCtx, {
                                        type: 'bar',
                                        data: {
                                            labels: <?php echo json_encode($labels); ?>,
                                            datasets: [{
                                                label: 'Faturamento (R$)',
                                                data: <?php echo json_encode($values); ?>,
                                                backgroundColor: 'rgba(46, 204, 113, 0.7)',
                                                borderColor: 'rgba(46, 204, 113, 1)',
                                                borderWidth: 1
                                            }]
                                        },
                                        options: {
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
                        <?php elseif ($report_type === 'imoveis'): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Imóvel</th>
                                            <th>Localização</th>
                                            <th>Reservas</th>
                                            <th>Diárias</th>
                                            <th>Taxa de Ocupação</th>
                                            <th>Faturamento</th>
                                            <th>Média por Diária</th>
                                            <th>Diária Cadastrada</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['titulo']); ?></td>
                                                <td><?php echo htmlspecialchars($item['cidade'] . ', ' . $item['estado']); ?></td>
                                                <td><?php echo $item['total_reservas']; ?></td>
                                                <td><?php echo $item['total_diarias']; ?></td>
                                                <td><?php echo number_format($item['ocupacao'], 2); ?>%</td>
                                                <td>R$ <?php echo number_format($item['receita_total'], 2, ',', '.'); ?></td>
                                                <td>R$ <?php echo number_format($item['media_diaria'], 2, ',', '.'); ?></td>
                                                <td>R$ <?php echo number_format($item['valor_diaria'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif ($report_type === 'clientes'): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Cliente</th>
                                            <th>Email</th>
                                            <th>Reservas</th>
                                            <th>Valor Total</th>
                                            <th>Primeira Reserva</th>
                                            <th>Última Reserva</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($report_data as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['nome']); ?></td>
                                                <td><?php echo htmlspecialchars($item['email']); ?></td>
                                                <td><?php echo $item['total_reservas']; ?></td>
                                                <td>R$ <?php echo number_format($item['valor_total'], 2, ',', '.'); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($item['primeira_reserva'])); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($item['ultima_reserva'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php elseif (!empty($report_type)): ?>
                <div class="alert alert-info">
                    Nenhum dado encontrado para o período selecionado.
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-body text-center p-5">
                        <i class="fas fa-chart-bar fa-4x text-muted mb-3"></i>
                        <h4>Selecione um tipo de relatório</h4>
                        <p class="text-muted">Escolha o tipo de relatório, o período e o imóvel (opcional) para gerar os dados.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>