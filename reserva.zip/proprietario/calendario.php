<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];

// Buscar imóveis do proprietário
$stmt = $pdo->prepare("SELECT id, titulo, cidade, estado FROM imoveis WHERE id_proprietario = ? ORDER BY titulo");
$stmt->execute([$user_id]);
$imoveis = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filtrar por imóvel específico
$imovel_id = isset($_GET['imovel_id']) ? intval($_GET['imovel_id']) : 0;

// Se um imóvel específico foi selecionado, verificar se pertence ao proprietário
if ($imovel_id > 0) {
    $found = false;
    foreach ($imoveis as $imovel) {
        if ($imovel['id'] == $imovel_id) {
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $imovel_id = 0;
    }
}

// Buscar período do calendário
$mes_atual = isset($_GET['mes']) ? intval($_GET['mes']) : date('n');
$ano_atual = isset($_GET['ano']) ? intval($_GET['ano']) : date('Y');

// Validar mês e ano
if ($mes_atual < 1 || $mes_atual > 12) {
    $mes_atual = date('n');
}

if ($ano_atual < date('Y') || $ano_atual > date('Y') + 2) {
    $ano_atual = date('Y');
}

// Buscar eventos (reservas) para o calendário
$eventos = [];
$where = "r.status = 'confirmada' AND YEAR(r.data_entrada) = ? AND MONTH(r.data_entrada) = ?";
$params = [$ano_atual, $mes_atual];

if ($imovel_id > 0) {
    $where .= " AND i.id = ?";
    $params[] = $imovel_id;
} else {
    $where .= " AND i.id_proprietario = ?";
    $params[] = $user_id;
}

$sql = "
    SELECT 
        r.id, r.data_entrada, r.data_saida, i.id as imovel_id, i.titulo as imovel_titulo,
        u.nome as cliente_nome
    FROM reservas r
    JOIN imoveis i ON r.id_imovel = i.id
    JOIN usuarios u ON r.id_usuario = u.id
    WHERE $where
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formatar eventos para o calendário
foreach ($reservas as $reserva) {
    $data_entrada = new DateTime($reserva['data_entrada']);
    $data_saida = new DateTime($reserva['data_saida']);
    
    // Adicionar todos os dias entre entrada e saída
    $periodo = new DatePeriod(
        $data_entrada,
        new DateInterval('P1D'),
        $data_saida->modify('+1 day')
    );
    
    foreach ($periodo as $data) {
        $data_formatada = $data->format('Y-m-d');
        
        if (!isset($eventos[$data_formatada])) {
            $eventos[$data_formatada] = [];
        }
        
        $eventos[$data_formatada][] = [
            'id' => $reserva['id'],
            'imovel_id' => $reserva['imovel_id'],
            'imovel_titulo' => $reserva['imovel_titulo'],
            'cliente_nome' => $reserva['cliente_nome'],
            'data_entrada' => $data_entrada->format('Y-m-d'),
            'data_saida' => $data_saida->format('Y-m-d')
        ];
    }
}

// Funções para o calendário
function mostrarCalendario($mes, $ano, $eventos) {
    $primeiro_dia = mktime(0, 0, 0, $mes, 1, $ano);
    $dias_no_mes = date('t', $primeiro_dia);
    $dia_da_semana = date('w', $primeiro_dia);
    
    $meses = [
        1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Março', 4 => 'Abril',
        5 => 'Maio', 6 => 'Junho', 7 => 'Julho', 8 => 'Agosto',
        9 => 'Setembro', 10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro'
    ];
    
    $calendario = '<div class="calendar">';
    $calendario .= '<div class="calendar-header">';
    $calendario .= '<h3>' . $meses[$mes] . ' ' . $ano . '</h3>';
    $calendario .= '</div>';
    
    // Dias da semana
    $calendario .= '<div class="days-of-week">';
    $calendario .= '<div>Dom</div>';
    $calendario .= '<div>Seg</div>';
    $calendario .= '<div>Ter</div>';
    $calendario .= '<div>Qua</div>';
    $calendario .= '<div>Qui</div>';
    $calendario .= '<div>Sex</div>';
    $calendario .= '<div>Sáb</div>';
    $calendario .= '</div>';
    
    // Começar o calendário
    $calendario .= '<div class="calendar-days">';
    
    // Preencher espaços vazios no início
    for ($i = 0; $i < $dia_da_semana; $i++) {
        $calendario .= '<div class="calendar-day empty"></div>';
    }
    
    // Dias do mês
    for ($dia = 1; $dia <= $dias_no_mes; $dia++) {
        $data = sprintf('%04d-%02d-%02d', $ano, $mes, $dia);
        $hoje = date('Y-m-d') === $data ? 'today' : '';
        $has_events = isset($eventos[$data]) ? 'has-events' : '';
        
        $calendario .= '<div class="calendar-day ' . $hoje . ' ' . $has_events . '">';
        $calendario .= '<div class="day-number">' . $dia . '</div>';
        
        // Adicionar eventos para este dia
        if (isset($eventos[$data])) {
            $calendario .= '<div class="day-events">';
            foreach ($eventos[$data] as $evento) {
                $entrada = $evento['data_entrada'] === $data ? 'entry-day' : '';
                $saida = $evento['data_saida'] === $data ? 'exit-day' : '';
                
                $calendario .= '<a href="reserva-detalhes.php?id=' . $evento['id'] . '" ';
                $calendario .= 'class="event ' . $entrada . ' ' . $saida . '" ';
                $calendario .= 'title="' . $evento['imovel_titulo'] . ' - ' . $evento['cliente_nome'] . '">';
                
                if ($entrada) {
                    $calendario .= '<i class="fas fa-sign-in-alt"></i> ';
                } else if ($saida) {
                    $calendario .= '<i class="fas fa-sign-out-alt"></i> ';
                }
                
                $calendario .= $evento['imovel_titulo'];
                $calendario .= '</a>';
            }
            $calendario .= '</div>';
        }
        
        $calendario .= '</div>';
    }
    
    // Preencher espaços vazios no final
    $dias_total = $dia_da_semana + $dias_no_mes;
    $dias_restantes = 7 - ($dias_total % 7);
    if ($dias_restantes < 7) {
        for ($i = 0; $i < $dias_restantes; $i++) {
            $calendario .= '<div class="calendar-day empty"></div>';
        }
    }
    
    $calendario .= '</div>'; // Fecha calendar-days
    $calendario .= '</div>'; // Fecha calendar
    
    return $calendario;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário de Reservas - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .calendar {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .calendar-header {
            background-color: #f8f9fa;
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        
        .days-of-week {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            text-align: center;
            font-weight: bold;
            background-color: #f8f9fa;
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        
        .calendar-days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
        }
        
        .calendar-day {
            min-height: 100px;
            padding: 5px;
            border-right: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
            position: relative;
        }
        
        .calendar-day:nth-child(7n) {
            border-right: none;
        }
        
        .calendar-day.empty {
            background-color: #f9f9f9;
        }
        
        .calendar-day.today {
            background-color: #fffde7;
        }
        
        .day-number {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .day-events {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }
        
        .event {
            background-color: #3498db;
            color: white;
            padding: 2px 5px;
            border-radius: 3px;
            font-size: 0.8rem;
            text-decoration: none;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .event.entry-day {
            border-left: 4px solid #28a745;
        }
        
        .event.exit-day {
            border-right: 4px solid #dc3545;
        }
        
        .event:hover {
            opacity: 0.9;
            color: white;
        }
        
        .month-selector {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .month-selector .btn-group {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Calendário de Reservas</h2>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form action="calendario.php" method="GET" class="row g-3">
                        <div class="col-md-6">
                            <label for="imovel_id" class="form-label">Imóvel</label>
                            <select name="imovel_id" id="imovel_id" class="form-select">
                                <option value="0">Todos os imóveis</option>
                                <?php foreach ($imoveis as $imovel): ?>
                                    <option value="<?php echo $imovel['id']; ?>" <?php echo $imovel_id == $imovel['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($imovel['titulo'] . ' (' . $imovel['cidade'] . '-' . $imovel['estado'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="mes" class="form-label">Mês</label>
                            <select name="mes" id="mes" class="form-select">
                                <?php for ($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $mes_atual == $i ? 'selected' : ''; ?>>
                                        <?php echo date('F', mktime(0, 0, 0, $i, 1)); ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="ano" class="form-label">Ano</label>
                            <select name="ano" id="ano" class="form-select">
                                <?php for ($i = date('Y'); $i <= date('Y') + 2; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $ano_atual == $i ? 'selected' : ''; ?>>
                                        <?php echo $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="month-selector">
                <?php
                // Mês anterior
                $mes_anterior = $mes_atual - 1;
                $ano_anterior = $ano_atual;
                if ($mes_anterior < 1) {
                    $mes_anterior = 12;
                    $ano_anterior--;
                }
                
                // Mês seguinte
                $mes_seguinte = $mes_atual + 1;
                $ano_seguinte = $ano_atual;
                if ($mes_seguinte > 12) {
                    $mes_seguinte = 1;
                    $ano_seguinte++;
                }
                ?>
                
                <div>
                    <a href="calendario.php?mes=<?php echo $mes_anterior; ?>&ano=<?php echo $ano_anterior; ?>&imovel_id=<?php echo $imovel_id; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-chevron-left"></i> Mês Anterior
                    </a>
                    <a href="calendario.php?mes=<?php echo date('n'); ?>&ano=<?php echo date('Y'); ?>&imovel_id=<?php echo $imovel_id; ?>" class="btn btn-outline-secondary">
                        Mês Atual
                    </a>
                    <a href="calendario.php?mes=<?php echo $mes_seguinte; ?>&ano=<?php echo $ano_seguinte; ?>&imovel_id=<?php echo $imovel_id; ?>" class="btn btn-outline-primary">
                        Próximo Mês <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body p-0">
                    <?php echo mostrarCalendario($mes_atual, $ano_atual, $eventos); ?>
                </div>
            </div>
            
            <div class="mt-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Legenda</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex gap-4">
                            <div>
                                <span class="badge bg-info"><i class="fas fa-info-circle"></i></span>
                                <span>Dia atual</span>
                            </div>
                            <div>
                                <span class="event" style="width: 80px;"><i class="fas fa-sign-in-alt"></i> Entrada</span>
                            </div>
                            <div>
                                <span class="event" style="width: 80px;"><i class="fas fa-sign-out-alt"></i> Saída</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>
