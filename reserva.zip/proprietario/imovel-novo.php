<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

$errors = [];
$success = false;

// Processar o formulário quando enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dados básicos do imóvel
    $titulo = filter_input(INPUT_POST, 'titulo', FILTER_SANITIZE_STRING);
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $quartos = filter_input(INPUT_POST, 'quartos', FILTER_SANITIZE_NUMBER_INT);
    $banheiros = filter_input(INPUT_POST, 'banheiros', FILTER_SANITIZE_NUMBER_INT);
    $capacidade = filter_input(INPUT_POST, 'capacidade', FILTER_SANITIZE_NUMBER_INT);
    $camas = filter_input(INPUT_POST, 'camas', FILTER_SANITIZE_NUMBER_INT);
    $area = filter_input(INPUT_POST, 'area', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $valor_diaria = filter_input(INPUT_POST, 'valor_diaria', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $taxa_limpeza = filter_input(INPUT_POST, 'taxa_limpeza', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    $taxa_servico = filter_input(INPUT_POST, 'taxa_servico', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    
    // Endereço
    $cep = filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_STRING);
    $endereco = filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
    $numero = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_STRING);
    $complemento = filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_STRING);
    $bairro = filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_STRING);
    $cidade = filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_STRING);
    $estado = filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_STRING);
    
    // Validações básicas
    if (empty($titulo)) {
        $errors[] = 'O título do imóvel é obrigatório';
    }
    
    if (empty($descricao)) {
        $errors[] = 'A descrição do imóvel é obrigatória';
    }
    
    if (empty($quartos) || $quartos < 1) {
        $errors[] = 'Informe o número de quartos';
    }
    
    if (empty($banheiros) || $banheiros < 1) {
        $errors[] = 'Informe o número de banheiros';
    }
    
    if (empty($capacidade) || $capacidade < 1) {
        $errors[] = 'Informe a capacidade de pessoas';
    }
    
    if (empty($valor_diaria) || $valor_diaria <= 0) {
        $errors[] = 'O valor da diária deve ser maior que zero';
    }
    
    if (empty($cep)) {
        $errors[] = 'O CEP é obrigatório';
    }
    
    if (empty($endereco)) {
        $errors[] = 'O endereço é obrigatório';
    }
    
    if (empty($numero)) {
        $errors[] = 'O número é obrigatório';
    }
    
    if (empty($bairro)) {
        $errors[] = 'O bairro é obrigatório';
    }
    
    if (empty($cidade)) {
        $errors[] = 'A cidade é obrigatória';
    }
    
    if (empty($estado)) {
        $errors[] = 'O estado é obrigatório';
    }
    
    // Foto principal
    if (empty($_FILES['foto_principal']['name'])) {
        $errors[] = 'A foto principal é obrigatória';
    }
    
    // Se não houver erros, proceder com o cadastro
    if (empty($errors)) {
        try {
            // Upload da foto principal
            $foto_principal = '';
            if ($_FILES['foto_principal']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../uploads/imoveis/';
                
                // Criar diretório se não existir
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $file_tmp = $_FILES['foto_principal']['tmp_name'];
                $file_name = basename($_FILES['foto_principal']['name']);
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                // Verificar extensão
                $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
                if (!in_array($file_ext, $allowed_exts)) {
                    $errors[] = 'Formato de arquivo não permitido. Use JPG, JPEG, PNG ou GIF.';
                    throw new Exception('Formato de arquivo não permitido');
                }
                
                // Gerar nome único
                $new_filename = uniqid('imovel_') . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                // Fazer upload
                if (move_uploaded_file($file_tmp, $upload_path)) {
                    $foto_principal = $upload_path;
                } else {
                    $errors[] = 'Erro ao fazer upload da imagem';
                    throw new Exception('Erro ao fazer upload da imagem');
                }
            }
            
            // Gerar slug
            $slug = generate_slug($titulo);
            
            // Verificar se o slug já existe
            $stmt = $pdo->prepare("SELECT id FROM imoveis WHERE slug = ?");
            $stmt->execute([$slug]);
            if ($stmt->rowCount() > 0) {
                $slug = $slug . '-' . uniqid();
            }
            
            $pdo->beginTransaction();
            
            // Inserir imóvel
            $stmt = $pdo->prepare("
                INSERT INTO imoveis (
                    id_proprietario, titulo, slug, descricao, quartos, banheiros, capacidade, camas, 
                    area, valor_diaria, taxa_limpeza, taxa_servico, cep, endereco, 
                    numero, complemento, bairro, cidade, estado, foto_principal, 
                    status, data_cadastro
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ativo', NOW()
                )
            ");
            
            $stmt->execute([
                $_SESSION['user_id'], $titulo, $slug, $descricao, $quartos, $banheiros, 
                $capacidade, $camas, $area, $valor_diaria, $taxa_limpeza, $taxa_servico, 
                $cep, $endereco, $numero, $complemento, $bairro, $cidade, $estado, $foto_principal
            ]);
            
            $imovel_id = $pdo->lastInsertId();
            
            // Inserir características
            $caracteristicas = [
                'wifi' => isset($_POST['wifi']) ? 1 : 0,
                'ar_condicionado' => isset($_POST['ar_condicionado']) ? 1 : 0,
                'piscina' => isset($_POST['piscina']) ? 1 : 0,
                'churrasqueira' => isset($_POST['churrasqueira']) ? 1 : 0,
                'estacionamento' => isset($_POST['estacionamento']) ? 1 : 0,
                'tv' => isset($_POST['tv']) ? 1 : 0,
                'cozinha' => isset($_POST['cozinha']) ? 1 : 0,
                'maquina_lavar' => isset($_POST['maquina_lavar']) ? 1 : 0,
                'pet_friendly' => isset($_POST['pet_friendly']) ? 1 : 0,
                'vista_mar' => isset($_POST['vista_mar']) ? 1 : 0,
                'varanda' => isset($_POST['varanda']) ? 1 : 0
            ];
            
            $stmt = $pdo->prepare("
                INSERT INTO caracteristicas_imoveis (
                    id_imovel, wifi, ar_condicionado, piscina, churrasqueira, 
                    estacionamento, tv, cozinha, maquina_lavar, pet_friendly, vista_mar, varanda
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            ");
            
            $stmt->execute([
                $imovel_id, $caracteristicas['wifi'], $caracteristicas['ar_condicionado'], 
                $caracteristicas['piscina'], $caracteristicas['churrasqueira'], 
                $caracteristicas['estacionamento'], $caracteristicas['tv'], 
                $caracteristicas['cozinha'], $caracteristicas['maquina_lavar'], 
                $caracteristicas['pet_friendly'], $caracteristicas['vista_mar'], 
                $caracteristicas['varanda']
            ]);
            
            // Inserir regras
            if (isset($_POST['regras']) && is_array($_POST['regras'])) {
                $stmt = $pdo->prepare("INSERT INTO regras_imoveis (id_imovel, regra) VALUES (?, ?)");
                
                foreach ($_POST['regras'] as $regra) {
                    if (!empty($regra)) {
                        $stmt->execute([$imovel_id, $regra]);
                    }
                }
            }
            
            $pdo->commit();
            $success = true;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Erro ao cadastrar imóvel: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Novo Imóvel - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Adicionar Novo Imóvel</h2>
                </div>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Imóvel cadastrado com sucesso!
                    <div class="mt-3">
                        <a href="imoveis.php" class="btn btn-primary">Ver Todos os Imóveis</a>
                        <a href="imovel-novo.php" class="btn btn-outline-primary">Cadastrar Outro Imóvel</a>
                    </div>
                </div>
            <?php else: ?>
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form action="imovel-novo.php" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <h4>Informações Básicas</h4>
                                </div>
                                
                                <div class="col-md-12 mb-3">
                                    <label for="titulo" class="form-label">Título do Imóvel *</label>
                                    <input type="text" class="form-control" id="titulo" name="titulo" required>
                                </div>
                                
                                <div class="col-md-12 mb-3">
                                    <label for="descricao" class="form-label">Descrição *</label>
                                    <textarea class="form-control" id="descricao" name="descricao" rows="4" required></textarea>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="quartos" class="form-label">Quartos *</label>
                                    <input type="number" class="form-control" id="quartos" name="quartos" min="1" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="banheiros" class="form-label">Banheiros *</label>
                                    <input type="number" class="form-control" id="banheiros" name="banheiros" min="1" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="capacidade" class="form-label">Capacidade (pessoas) *</label>
                                    <input type="number" class="form-control" id="capacidade" name="capacidade" min="1" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="camas" class="form-label">Número de Camas</label>
                                    <input type="number" class="form-control" id="camas" name="camas" min="1">
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="area" class="form-label">Área (m²)</label>
                                    <input type="number" class="form-control" id="area" name="area" step="0.01" min="1">
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="valor_diaria" class="form-label">Valor da Diária (R$) *</label>
                                    <input type="number" class="form-control" id="valor_diaria" name="valor_diaria" step="0.01" min="1" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="taxa_limpeza" class="form-label">Taxa de Limpeza (R$)</label>
                                    <input type="number" class="form-control" id="taxa_limpeza" name="taxa_limpeza" step="0.01" min="0">
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="taxa_servico" class="form-label">Taxa de Serviço (R$)</label>
                                    <input type="number" class="form-control" id="taxa_servico" name="taxa_servico" step="0.01" min="0">
                                </div>
                                
                                <div class="col-md-12 mt-3 mb-3">
                                    <h4>Endereço</h4>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="cep" class="form-label">CEP *</label>
                                    <input type="text" class="form-control" id="cep" name="cep" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="endereco" class="form-label">Endereço *</label>
                                    <input type="text" class="form-control" id="endereco" name="endereco" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="numero" class="form-label">Número *</label>
                                    <input type="text" class="form-control" id="numero" name="numero" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="complemento" class="form-label">Complemento</label>
                                    <input type="text" class="form-control" id="complemento" name="complemento">
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="bairro" class="form-label">Bairro *</label>
                                    <input type="text" class="form-control" id="bairro" name="bairro" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="cidade" class="form-label">Cidade *</label>
                                    <input type="text" class="form-control" id="cidade" name="cidade" required>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="estado" class="form-label">Estado *</label>
                                    <select class="form-select" id="estado" name="estado" required>
                                        <option value="">Selecione</option>
                                        <option value="AC">Acre</option>
                                        <option value="AL">Alagoas</option>
                                        <option value="AP">Amapá</option>
                                        <option value="AM">Amazonas</option>
                                        <option value="BA">Bahia</option>
                                        <option value="CE">Ceará</option>
                                        <option value="DF">Distrito Federal</option>
                                        <option value="ES">Espírito Santo</option>
                                        <option value="GO">Goiás</option>
                                        <option value="MA">Maranhão</option>
                                        <option value="MT">Mato Grosso</option>
                                        <option value="MS">Mato Grosso do Sul</option>
                                        <option value="MG">Minas Gerais</option>
                                        <option value="PA">Pará</option>
                                        <option value="PB">Paraíba</option>
                                        <option value="PR">Paraná</option>
                                        <option value="PE">Pernambuco</option>
                                        <option value="PI">Piauí</option>
                                        <option value="RJ">Rio de Janeiro</option>
                                        <option value="RN">Rio Grande do Norte</option>
                                        <option value="RS">Rio Grande do Sul</option>
                                        <option value="RO">Rondônia</option>
                                        <option value="RR">Roraima</option>
                                        <option value="SC">Santa Catarina</option>
                                        <option value="SP">São Paulo</option>
                                        <option value="SE">Sergipe</option>
                                        <option value="TO">Tocantins</option>
                                    </select>
                                </div>
                                
                                <div class="col-md-12 mt-3 mb-3">
                                    <h4>Características</h4>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="wifi" name="wifi">
                                        <label class="form-check-label" for="wifi">
                                            <i class="fas fa-wifi me-1"></i> Wi-Fi
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="ar_condicionado" name="ar_condicionado">
                                        <label class="form-check-label" for="ar_condicionado">
                                            <i class="fas fa-snowflake me-1"></i> Ar Condicionado
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="piscina" name="piscina">
                                        <label class="form-check-label" for="piscina">
                                            <i class="fas fa-swimming-pool me-1"></i> Piscina
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="churrasqueira" name="churrasqueira">
                                        <label class="form-check-label" for="churrasqueira">
                                            <i class="fas fa-fire me-1"></i> Churrasqueira
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="estacionamento" name="estacionamento">
                                        <label class="form-check-label" for="estacionamento">
                                            <i class="fas fa-car me-1"></i> Estacionamento
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="tv" name="tv">
                                        <label class="form-check-label" for="tv">
                                            <i class="fas fa-tv me-1"></i> TV
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="cozinha" name="cozinha">
                                        <label class="form-check-label" for="cozinha">
                                            <i class="fas fa-utensils me-1"></i> Cozinha
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="maquina_lavar" name="maquina_lavar">
                                        <label class="form-check-label" for="maquina_lavar">
                                            <i class="fas fa-tshirt me-1"></i> Máquina de Lavar
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="pet_friendly" name="pet_friendly">
                                        <label class="form-check-label" for="pet_friendly">
                                            <i class="fas fa-paw me-1"></i> Pet Friendly
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="vista_mar" name="vista_mar">
                                        <label class="form-check-label" for="vista_mar">
                                            <i class="fas fa-water me-1"></i> Vista para o Mar
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="varanda" name="varanda">
                                        <label class="form-check-label" for="varanda">
                                            <i class="fas fa-door-open me-1"></i> Varanda
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mt-3 mb-3">
                                    <h4>Regras do Imóvel</h4>
                                    <p class="text-muted">Adicione as regras específicas do seu imóvel, como horários de check-in/check-out, restrições, etc.</p>
                                    
                                    <div id="regras-container">
                                        <div class="row mb-2">
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" name="regras[]" placeholder="Ex: Check-in das 14h às 20h">
                                            </div>
                                            <div class="col-md-2">
                                                <button type="button" class="btn btn-success w-100" id="add-regra">
                                                    <i class="fas fa-plus"></i> Adicionar
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mt-3 mb-3">
                                    <h4>Foto Principal *</h4>
                                    <div class="mb-3">
                                        <input class="form-control" type="file" id="foto_principal" name="foto_principal" accept="image/*" required>
                                        <div class="form-text">Essa será a foto principal exibida nos resultados de busca. Você poderá adicionar mais fotos após cadastrar o imóvel.</div>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mt-3">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i> Após cadastrar o imóvel, você poderá adicionar mais fotos, definir períodos de indisponibilidade e configurar outras opções.
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> Cadastrar Imóvel
                                    </button>
                                    <a href="imoveis.php" class="btn btn-outline-secondary">Cancelar</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Consulta de CEP
            document.getElementById('cep').addEventListener('blur', function() {
                const cep = this.value.replace(/\D/g, '');
                
                if (cep.length !== 8) return;
                
                fetch(`https://viacep.com.br/ws/${cep}/json/`)
                    .then(response => response.json())
                    .then(data => {
                        if (!data.erro) {
                            document.getElementById('endereco').value = data.logradouro;
                            document.getElementById('bairro').value = data.bairro;
                            document.getElementById('cidade').value = data.localidade;
                            document.getElementById('estado').value = data.uf;
                            document.getElementById('numero').focus();
                        }
                    })
                    .catch(error => console.error('Erro ao buscar CEP:', error));
            });
            
            // Adicionar regras dinamicamente
            document.getElementById('add-regra').addEventListener('click', function() {
                const container = document.getElementById('regras-container');
                const newRow = document.createElement('div');
                newRow.className = 'row mb-2';
                newRow.innerHTML = `
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="regras[]" placeholder="Ex: Check-in das 14h às 20h">
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-danger w-100 remove-regra">
                            <i class="fas fa-trash"></i> Remover
                        </button>
                    </div>
                `;
                
                container.appendChild(newRow);
                
                // Adicionar evento para remover regra
                newRow.querySelector('.remove-regra').addEventListener('click', function() {
                    container.removeChild(newRow);
                });
            });
        });
    </script>
</body>
</html>