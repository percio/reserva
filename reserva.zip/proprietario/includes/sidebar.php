<div class="sidebar">
    <div class="sidebar-header">
        <h3>Proprie<span>tário</span></h3>
    </div>
    
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="imoveis.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'imoveis.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Meus Imóveis</span>
                </a>
            </li>
            <li>
                <a href="imovel-novo.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'imovel-novo.php' ? 'active' : ''; ?>">
                    <i class="fas fa-plus-circle"></i>
                    <span>Adicionar Imóvel</span>
                </a>
            </li>
            <li>
                <a href="reservas.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'reservas.php' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-check"></i>
                    <span>Reservas</span>
                </a>
            </li>
            <li>
                <a href="calendario.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'calendario.php' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Calendário</span>
                </a>
            </li>
            <li>
                <a href="avaliacoes.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'avaliacoes.php' ? 'active' : ''; ?>">
                    <i class="fas fa-star"></i>
                    <span>Avaliações</span>
                </a>
            </li>
            <li>
                <a href="mensagens.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'mensagens.php' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i>
                    <span>Mensagens</span>
                </a>
            </li>
            <li>
                <a href="relatorio.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'relatorio.php' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i>
                    <span>Relatório</span>
                </a>
            </li>
            <li>
                <a href="perfil.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'perfil.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user"></i>
                    <span>Meu Perfil</span>
                </a>
            </li>
            <li>
                <a href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </li>
        </ul>
    </div>
</div>

