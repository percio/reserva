<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Verificar se o ID foi informado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID do imóvel não especificado";
    redirect('imoveis.php');
}

$imovel_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Verificar se o imóvel pertence ao proprietário
$stmt = $pdo->prepare("SELECT * FROM imoveis WHERE id = ? AND id_proprietario = ?");
$stmt->execute([$imovel_id, $user_id]);
$imovel = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$imovel) {
    $_SESSION['error'] = "Imóvel não encontrado ou sem permissão para editar";
    redirect('imoveis.php');
}

// Processar ações
if (isset($_GET['action']) && isset($_GET['photo_id']) && is_numeric($_GET['photo_id'])) {
    $action = $_GET['action'];
    $photo_id = intval($_GET['photo_id']);
    
    // Verificar se a foto pertence ao imóvel do proprietário
    $stmt = $pdo->prepare("
        SELECT i.* FROM imagens_imoveis i
        JOIN imoveis p ON i.id_imovel = p.id
        WHERE i.id = ? AND i.id_imovel = ? AND p.id_proprietario = ?
    ");
    $stmt->execute([$photo_id, $imovel_id, $user_id]);
    $foto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$foto) {
        $_SESSION['error'] = "Foto não encontrada ou sem permissão para modificar";
        redirect("imovel-fotos.php?id=$imovel_id");
    }
    
    switch ($action) {
        case 'delete':
            try {
                $stmt = $pdo->prepare("DELETE FROM imagens_imoveis WHERE id = ?");
                $stmt->execute([$photo_id]);
                $_SESSION['success'] = "Foto excluída com sucesso";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao excluir foto: " . $e->getMessage();
            }
            break;
            
        case 'set_main':
            try {
                $pdo->beginTransaction();
                
                // Obter a foto atual
                $stmt = $pdo->prepare("SELECT imagem FROM imagens_imoveis WHERE id = ?");
                $stmt->execute([$photo_id]);
                $imagem = $stmt->fetchColumn();
                
                // Atualizar a foto principal do imóvel
                $stmt = $pdo->prepare("UPDATE imoveis SET foto_principal = ? WHERE id = ?");
                $stmt->execute([$imagem, $imovel_id]);
                
                $pdo->commit();
                $_SESSION['success'] = "Foto principal atualizada com sucesso";
            } catch (PDOException $e) {
                $pdo->rollBack();
                $_SESSION['error'] = "Erro ao atualizar foto principal: " . $e->getMessage();
            }
            break;
    }
    
    redirect("imovel-fotos.php?id=$imovel_id");
}

// Processar upload de novas fotos
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fotos'])) {
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $upload_dir = '../uploads/imoveis/';
    
    // Criar diretório se não existir
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    // Buscar a ordem mais alta atual
    $stmt = $pdo->prepare("SELECT MAX(ordem) FROM imagens_imoveis WHERE id_imovel = ?");
    $stmt->execute([$imovel_id]);
    $ordem = (int)$stmt->fetchColumn() + 1;
    
    $uploaded_count = 0;
    $error_count = 0;
    
    // Processar múltiplos arquivos
    for ($i = 0; $i < count($_FILES['fotos']['name']); $i++) {
        if ($_FILES['fotos']['error'][$i] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['fotos']['tmp_name'][$i];
            $file_name = basename($_FILES['fotos']['name'][$i]);
            $file_size = $_FILES['fotos']['size'][$i];
            $file_type = $_FILES['fotos']['type'][$i];
            
            // Verificar tipo
            if (!in_array($file_type, $allowed_types)) {
                $error_count++;
                continue;
            }
            
            // Verificar tamanho
            if ($file_size > $max_size) {
                $error_count++;
                continue;
            }
            
            // Gerar nome único
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $new_filename = uniqid('img_') . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($file_tmp, $upload_path)) {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO imagens_imoveis (id_imovel, imagem, descricao, ordem)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$imovel_id, $upload_path, $descricao, $ordem]);
                    $ordem++;
                    $uploaded_count++;
                } catch (PDOException $e) {
                    $error_count++;
                }
            } else {
                $error_count++;
            }
        } else {
            $error_count++;
        }
    }
    
    if ($uploaded_count > 0) {
        $_SESSION['success'] = "Foram enviadas $uploaded_count fotos com sucesso.";
        if ($error_count > 0) {
            $_SESSION['warning'] = "Não foi possível enviar $error_count fotos.";
        }
    } else {
        $_SESSION['error'] = "Erro ao enviar fotos. Verifique o formato e tamanho dos arquivos.";
    }
    
    redirect("imovel-fotos.php?id=$imovel_id");
}

// Buscar imagens existentes
$stmt = $pdo->prepare("SELECT * FROM imagens_imoveis WHERE id_imovel = ? ORDER BY ordem");
$stmt->execute([$imovel_id]);
$imagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Fotos - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .photo-card {
            position: relative;
            margin-bottom: 20px;
        }
        
        .photo-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }
        
        .photo-actions {
            position: absolute;
            bottom: 10px;
            right: 10px;
            display: flex;
            gap: 5px;
        }
        
        .main-photo-badge {
            position: absolute;
            top: 10px;
            left: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Gerenciar Fotos</h2>
                </div>
                <div class="dashboard-actions">
                    <a href="imovel-detalhes.php?id=<?php echo $imovel_id; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left"></i> Voltar para Detalhes
                    </a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['warning'])): ?>
                <div class="alert alert-warning">
                    <?php 
                    echo $_SESSION['warning']; 
                    unset($_SESSION['warning']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Adicionar Novas Fotos</h5>
                </div>
                <div class="card-body">
                    <form action="imovel-fotos.php?id=<?php echo $imovel_id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="fotos" class="form-label">Selecione as Fotos</label>
                            <input class="form-control" type="file" id="fotos" name="fotos[]" accept="image/*" multiple required>
                            <div class="form-text">Você pode selecionar múltiplas fotos de uma vez. Formatos permitidos: JPG, PNG, GIF. Tamanho máximo: 5MB por foto.</div>
                        </div>
                        <div class="mb-3">
                            <label for="descricao" class="form-label">Descrição (opcional)</label>
                            <input type="text" class="form-control" id="descricao" name="descricao" placeholder="Descrição para as fotos">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Enviar Fotos
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Galeria de Fotos</h5>
                    <span class="badge bg-info"><?php echo count($imagens); ?> fotos</span>
                </div>
                <div class="card-body">
                    <p class="text-muted mb-4">
                        A foto principal é mostrada primeiramente nos resultados de busca. 
                        Você pode definir qualquer foto como principal clicando no botão "Definir como Principal".
                    </p>
                    
                    <div class="row">
                        <!-- Foto Principal -->
                        <div class="col-md-4">
                            <div class="photo-card">
                                <img src="<?php echo htmlspecialchars($imovel['foto_principal']); ?>" alt="Foto Principal">
                                <div class="main-photo-badge">
                                    <span class="badge bg-primary">Foto Principal</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Outras Fotos -->
                        <?php foreach ($imagens as $imagem): ?>
                            <div class="col-md-4">
                                <div class="photo-card">
                                    <img src="<?php echo htmlspecialchars($imagem['imagem']); ?>" alt="<?php echo htmlspecialchars($imagem['descricao'] ?? 'Imagem do imóvel'); ?>">
                                    <?php if ($imagem['imagem'] === $imovel['foto_principal']): ?>
                                        <div class="main-photo-badge">
                                            <span class="badge bg-primary">Foto Principal</span>
                                        </div>
                                    <?php endif; ?>
                                    <div class="photo-actions">
                                        <?php if ($imagem['imagem'] !== $imovel['foto_principal']): ?>
                                            <a href="imovel-fotos.php?id=<?php echo $imovel_id; ?>&action=set_main&photo_id=<?php echo $imagem['id']; ?>" class="btn btn-sm btn-primary" title="Definir como Principal">
                                                <i class="fas fa-star"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $imagem['id']; ?>" title="Excluir">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        
                                        <!-- Delete Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo $imagem['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Tem certeza que deseja excluir esta foto?</p>
                                                        <img src="<?php echo htmlspecialchars($imagem['imagem']); ?>" alt="Imagem a ser excluída" class="img-fluid mb-3">
                                                        <p class="text-danger">Esta ação não pode ser desfeita!</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <a href="imovel-fotos.php?id=<?php echo $imovel_id; ?>&action=delete&photo_id=<?php echo $imagem['id']; ?>" class="btn btn-danger">Excluir</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if (empty($imagens)): ?>
                            <div class="col-12">
                                <div class="alert alert-info">
                                    Nenhuma foto adicional foi adicionada ao imóvel. Adicione fotos para melhorar a apresentação do seu imóvel.
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        // Preview das imagens selecionadas
        document.getElementById('fotos').addEventListener('change', function(e) {
            const files = e.target.files;
            const maxFiles = 10;
            
            if (files.length > maxFiles) {
                alert(`Você pode enviar no máximo ${maxFiles} fotos de uma vez.`);
                e.target.value = '';
                return;
            }
        });
    </script>
</body>
</html>