<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Verificar se o ID foi informado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID do imóvel não especificado";
    redirect('imoveis.php');
}

$imovel_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Verificar se o imóvel pertence ao proprietário
$stmt = $pdo->prepare("SELECT * FROM imoveis WHERE id = ? AND id_proprietario = ?");
$stmt->execute([$imovel_id, $user_id]);
$imovel = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$imovel) {
    $_SESSION['error'] = "Imóvel não encontrado ou sem permissão para visualizar";
    redirect('imoveis.php');
}

// Buscar características do imóvel
$stmt = $pdo->prepare("SELECT * FROM caracteristicas_imoveis WHERE id_imovel = ?");
$stmt->execute([$imovel_id]);
$caracteristicas = $stmt->fetch(PDO::FETCH_ASSOC);

// Buscar regras do imóvel
$stmt = $pdo->prepare("SELECT regra FROM regras_imoveis WHERE id_imovel = ? ORDER BY id");
$stmt->execute([$imovel_id]);
$regras = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Buscar imagens do imóvel
$stmt = $pdo->prepare("SELECT * FROM imagens_imoveis WHERE id_imovel = ? ORDER BY ordem");
$stmt->execute([$imovel_id]);
$imagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar estatísticas de reservas
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_reservas,
        SUM(CASE WHEN status = 'confirmada' THEN 1 ELSE 0 END) as reservas_confirmadas,
        SUM(CASE WHEN status = 'cancelada' THEN 1 ELSE 0 END) as reservas_canceladas,
        SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as reservas_pendentes,
        SUM(valor_total) as faturamento_total
    FROM reservas
    WHERE id_imovel = ?
");
$stmt->execute([$imovel_id]);
$estatisticas = $stmt->fetch(PDO::FETCH_ASSOC);

// Buscar próximas reservas
$stmt = $pdo->prepare("
    SELECT r.*, u.nome as usuario_nome, u.email as usuario_email, u.telefone as usuario_telefone
    FROM reservas r
    JOIN usuarios u ON r.id_usuario = u.id
    WHERE r.id_imovel = ? AND r.status = 'confirmada' AND r.data_entrada >= CURDATE()
    ORDER BY r.data_entrada ASC
    LIMIT 5
");
$stmt->execute([$imovel_id]);
$proximas_reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Imóvel - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Detalhes do Imóvel</h2>
                </div>
                <div class="dashboard-actions">
                    <a href="imovel-editar.php?id=<?php echo $imovel_id; ?>" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Editar Imóvel
                    </a>
                    <a href="imovel-fotos.php?id=<?php echo $imovel_id; ?>" class="btn btn-success">
                        <i class="fas fa-images"></i> Gerenciar Fotos
                    </a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-8">
                    <!-- Informações Básicas -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informações Básicas</h5>
                        </div>
                        <div class="card-body">
                            <div class="property-images mb-4">
                                <div id="propertyCarousel" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="<?php echo htmlspecialchars($imovel['foto_principal']); ?>" class="d-block w-100" alt="Foto Principal" style="height: 400px; object-fit: cover;">
                                        </div>
                                        <?php foreach ($imagens as $imagem): ?>
                                            <div class="carousel-item">
                                                <img src="<?php echo htmlspecialchars($imagem['imagem']); ?>" class="d-block w-100" alt="<?php echo htmlspecialchars($imagem['descricao'] ?? 'Imagem do imóvel'); ?>" style="height: 400px; object-fit: cover;">
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#propertyCarousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Anterior</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#propertyCarousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Próximo</span>
                                    </button>
                                </div>
                                <div class="mt-2 text-end">
                                    <a href="imovel-fotos.php?id=<?php echo $imovel_id; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-images"></i> Gerenciar Fotos (<?php echo count($imagens); ?>)
                                    </a>
                                </div>
                            </div>
                            
                            <h3 class="mb-3"><?php echo htmlspecialchars($imovel['titulo']); ?></h3>
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <p><strong>Localização:</strong> <?php echo htmlspecialchars($imovel['cidade'] . ', ' . $imovel['estado']); ?></p>
                                    <p><strong>Endereço:</strong> <?php echo htmlspecialchars($imovel['endereco'] . ', ' . $imovel['numero'] . ($imovel['complemento'] ? ', ' . $imovel['complemento'] : '')); ?></p>
                                    <p><strong>Bairro:</strong> <?php echo htmlspecialchars($imovel['bairro']); ?></p>
                                    <p><strong>CEP:</strong> <?php echo htmlspecialchars($imovel['cep']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Valor da Diária:</strong> R$ <?php echo number_format($imovel['valor_diaria'], 2, ',', '.'); ?></p>
                                    <p><strong>Taxa de Limpeza:</strong> R$ <?php echo number_format($imovel['taxa_limpeza'], 2, ',', '.'); ?></p>
                                    <p><strong>Taxa de Serviço:</strong> R$ <?php echo number_format($imovel['taxa_servico'], 2, ',', '.'); ?></p>
                                    <p><strong>Status:</strong> 
                                        <span class="badge <?php 
                                            echo $imovel['status'] === 'ativo' ? 'bg-success' : 
                                                ($imovel['status'] === 'inativo' ? 'bg-danger' : 'bg-warning'); 
                                        ?>">
                                            <?php echo ucfirst($imovel['status']); ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                            
                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <h5>Detalhes do Imóvel</h5>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <p><i class="fas fa-bed me-2"></i> <?php echo $imovel['quartos']; ?> quartos</p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><i class="fas fa-bath me-2"></i> <?php echo $imovel['banheiros']; ?> banheiros</p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><i class="fas fa-users me-2"></i> <?php echo $imovel['capacidade']; ?> pessoas</p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><i class="fas fa-ruler-combined me-2"></i> <?php echo $imovel['area']; ?> m²</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="property-description mb-4">
                                <h5>Descrição</h5>
                                <p><?php echo nl2br(htmlspecialchars($imovel['descricao'])); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Características -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Características</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['wifi'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Wi-Fi</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['ar_condicionado'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Ar Condicionado</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['piscina'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Piscina</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['churrasqueira'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Churrasqueira</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['estacionamento'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Estacionamento</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['tv'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>TV</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['cozinha'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Cozinha</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['maquina_lavar'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Máquina de Lavar</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['pet_friendly'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Pet Friendly</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['vista_mar'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Vista para o Mar</span>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-2">
                                    <div class="feature-item">
                                        <?php if (($caracteristicas['varanda'] ?? 0) == 1): ?>
                                            <i class="fas fa-check-circle text-success me-2"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle text-danger me-2"></i>
                                        <?php endif; ?>
                                        <span>Varanda</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Regras do Imóvel -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Regras do Imóvel</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($regras)): ?>
                                <p>Nenhuma regra específica foi definida para este imóvel.</p>
                            <?php else: ?>
                                <ul class="mb-0">
                                    <?php foreach ($regras as $regra): ?>
                                        <li><?php echo htmlspecialchars($regra); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <!-- Estatísticas -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Estatísticas</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <p class="mb-1"><strong>Total de Reservas:</strong></p>
                                <h4><?php echo $estatisticas['total_reservas'] ?: 0; ?></h4>
                            </div>
                            <div class="mb-2">
                                <p class="mb-1"><strong>Reservas Confirmadas:</strong></p>
                                <h4><?php echo $estatisticas['reservas_confirmadas'] ?: 0; ?></h4>
                            </div>
                            <div class="mb-2">
                                <p class="mb-1"><strong>Reservas Pendentes:</strong></p>
                                <h4><?php echo $estatisticas['reservas_pendentes'] ?: 0; ?></h4>
                            </div>
                            <div class="mb-2">
                                <p class="mb-1"><strong>Reservas Canceladas:</strong></p>
                                <h4><?php echo $estatisticas['reservas_canceladas'] ?: 0; ?></h4>
                            </div>
                            <div class="mb-2">
                                <p class="mb-1"><strong>Faturamento Total:</strong></p>
                                <h4>R$ <?php echo number_format($estatisticas['faturamento_total'] ?: 0, 2, ',', '.'); ?></h4>
                            </div>
                            
                            <div class="mt-3">
                                <a href="reservas.php?imovel=<?php echo $imovel_id; ?>" class="btn btn-primary w-100">
                                    <i class="fas fa-calendar-check"></i> Ver Todas as Reservas
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Ações Rápidas -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Ações Rápidas</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="imovel-editar.php?id=<?php echo $imovel_id; ?>" class="btn btn-primary">
                                    <i class="fas fa-edit"></i> Editar Imóvel
                                </a>
                                <a href="imovel-fotos.php?id=<?php echo $imovel_id; ?>" class="btn btn-success">
                                    <i class="fas fa-images"></i> Gerenciar Fotos
                                </a>
                                <a href="imovel-calendario.php?id=<?php echo $imovel_id; ?>" class="btn btn-info">
                                    <i class="fas fa-calendar-alt"></i> Gerenciar Disponibilidade
                                </a>
                                <a href="imoveis.php?action=<?php echo $imovel['status'] === 'ativo' ? 'deactivate' : 'activate'; ?>&id=<?php echo $imovel_id; ?>" class="btn <?php echo $imovel['status'] === 'ativo' ? 'btn-warning' : 'btn-success'; ?>">
                                    <i class="fas <?php echo $imovel['status'] === 'ativo' ? 'fa-pause-circle' : 'fa-play-circle'; ?>"></i> 
                                    <?php echo $imovel['status'] === 'ativo' ? 'Desativar Imóvel' : 'Ativar Imóvel'; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Próximas Reservas -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Próximas Reservas</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($proximas_reservas)): ?>
                                <p>Não há reservas futuras para este imóvel.</p>
                            <?php else: ?>
                                <ul class="list-group">
                                    <?php foreach ($proximas_reservas as $reserva): ?>
                                        <li class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-center mb-1">
                                                <strong><?php echo htmlspecialchars($reserva['usuario_nome']); ?></strong>
                                                <span class="badge bg-success">Confirmada</span>
                                            </div>
                                            <div class="mb-1">
                                                <i class="fas fa-calendar me-1"></i> 
                                                <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?> a 
                                                <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?>
                                            </div>
                                            <div class="mb-1">
                                                <i class="fas fa-dollar-sign me-1"></i> 
                                                R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?>
                                            </div>
                                            <div class="mt-2">
                                                <a href="reserva-detalhes.php?id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    Ver Detalhes
                                                </a>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>