<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Verificar se o ID foi informado
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID da reserva não especificado";
    redirect('reservas.php');
}

$reserva_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Verificar se a reserva pertence a um imóvel do proprietário
$stmt = $pdo->prepare("
    SELECT r.*, 
           u.nome as cliente_nome, u.email as cliente_email, u.telefone as cliente_telefone,
           i.titulo as imovel_titulo, i.endereco as imovel_endereco, i.numero as imovel_numero,
           i.bairro as imovel_bairro, i.cidade as imovel_cidade, i.estado as imovel_estado,
           i.foto_principal as imovel_foto
    FROM reservas r
    JOIN usuarios u ON r.id_usuario = u.id
    JOIN imoveis i ON r.id_imovel = i.id
    WHERE r.id = ? AND i.id_proprietario = ?
");
$stmt->execute([$reserva_id, $user_id]);
$reserva = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reserva) {
    $_SESSION['error'] = "Reserva não encontrada ou sem permissão para visualizar";
    redirect('reservas.php');
}

// Processar ações
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'confirm':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'confirmada' WHERE id = ?");
                $stmt->execute([$reserva_id]);
                $_SESSION['success'] = "Reserva confirmada com sucesso!";
                redirect("reserva-detalhes.php?id=$reserva_id");
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao confirmar reserva: " . $e->getMessage();
            }
            break;
            
        case 'cancel':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'cancelada' WHERE id = ?");
                $stmt->execute([$reserva_id]);
                $_SESSION['success'] = "Reserva cancelada com sucesso!";
                redirect("reserva-detalhes.php?id=$reserva_id");
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao cancelar reserva: " . $e->getMessage();
            }
            break;
            
        case 'complete':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'concluida' WHERE id = ?");
                $stmt->execute([$reserva_id]);
                $_SESSION['success'] = "Reserva marcada como concluída!";
                redirect("reserva-detalhes.php?id=$reserva_id");
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao concluir reserva: " . $e->getMessage();
            }
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes da Reserva - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Detalhes da Reserva</h2>
                </div>
                <div class="dashboard-actions">
                    <a href="reservas.php" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left"></i> Voltar para Reservas
                    </a>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Informações da Reserva</h5>
                            <span class="badge <?php 
                                echo $reserva['status'] === 'confirmada' ? 'bg-success' : 
                                    ($reserva['status'] === 'pendente' ? 'bg-warning' : 
                                    ($reserva['status'] === 'concluida' ? 'bg-secondary' : 'bg-danger')); 
                            ?>">
                                <?php echo ucfirst($reserva['status']); ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Código da Reserva:</strong> <?php echo htmlspecialchars($reserva['codigo']); ?></p>
                                    <p><strong>Data de Check-in:</strong> <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?></p>
                                    <p><strong>Data de Check-out:</strong> <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?></p>
                                    <p><strong>Hóspedes:</strong> <?php echo $reserva['adultos']; ?> adultos
                                        <?php if ($reserva['criancas'] > 0): ?>
                                            e <?php echo $reserva['criancas']; ?> crianças
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Data da Reserva:</strong> <?php echo date('d/m/Y H:i', strtotime($reserva['data_reserva'])); ?></p>
                                    <p><strong>Forma de Pagamento:</strong> <?php echo ucfirst($reserva['forma_pagamento']); ?></p>
                                    <p><strong>Valor da Diária:</strong> R$ <?php echo number_format($reserva['valor_diaria'], 2, ',', '.'); ?></p>
                                    <p><strong>Valor Total:</strong> <span class="fw-bold">R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></span></p>
                                </div>
                            </div>
                            
                            <?php if (!empty($reserva['observacoes'])): ?>
                                <div class="mt-3">
                                    <h6>Observações:</h6>
                                    <p><?php echo nl2br(htmlspecialchars($reserva['observacoes'])); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="mt-4">
                                <h6>Ações Disponíveis:</h6>
                                <div class="d-flex gap-2">
                                    <?php if ($reserva['status'] === 'pendente'): ?>
                                        <a href="reserva-detalhes.php?id=<?php echo $reserva_id; ?>&action=confirm" class="btn btn-success">
                                            <i class="fas fa-check"></i> Confirmar Reserva
                                        </a>
                                        <a href="reserva-detalhes.php?id=<?php echo $reserva_id; ?>&action=cancel" class="btn btn-danger">
                                            <i class="fas fa-times"></i> Cancelar Reserva
                                        </a>
                                    <?php elseif ($reserva['status'] === 'confirmada'): ?>
                                        <a href="reserva-detalhes.php?id=<?php echo $reserva_id; ?>&action=complete" class="btn btn-secondary">
                                            <i class="fas fa-check-double"></i> Marcar como Concluída
                                        </a>
                                        <a href="reserva-detalhes.php?id=<?php echo $reserva_id; ?>&action=cancel" class="btn btn-danger">
                                            <i class="fas fa-times"></i> Cancelar Reserva
                                        </a>
                                    <?php endif; ?>
                                    
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#contactModal">
                                        <i class="fas fa-envelope"></i> Contactar Cliente
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Detalhes do Imóvel</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <img src="<?php echo htmlspecialchars($reserva['imovel_foto']); ?>" alt="<?php echo htmlspecialchars($reserva['imovel_titulo']); ?>" class="img-fluid rounded">
                                </div>
                                <div class="col-md-8">
                                    <h5><?php echo htmlspecialchars($reserva['imovel_titulo']); ?></h5>
                                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($reserva['imovel_endereco'] . ', ' . $reserva['imovel_numero'] . ' - ' . $reserva['imovel_bairro'] . ', ' . $reserva['imovel_cidade'] . '/' . $reserva['imovel_estado']); ?></p>
                                    <a href="imovel-detalhes.php?id=<?php echo $reserva['id_imovel']; ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-info-circle"></i> Ver Detalhes do Imóvel
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Dados do Cliente</h5>
                        </div>
                        <div class="card-body">
                            <h5><?php echo htmlspecialchars($reserva['cliente_nome']); ?></h5>
                            <p><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($reserva['cliente_email']); ?></p>
                            <p><i class="fas fa-phone"></i> <?php echo htmlspecialchars($reserva['cliente_telefone']); ?></p>
                            
                            <div class="mt-3">
                                <a href="tel:<?php echo preg_replace('/[^0-9]/', '', $reserva['cliente_telefone']); ?>" class="btn btn-success btn-sm">
                                    <i class="fas fa-phone"></i> Ligar
                                </a>
                                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $reserva['cliente_telefone']); ?>" target="_blank" class="btn btn-success btn-sm">
                                    <i class="fab fa-whatsapp"></i> WhatsApp
                                </a>
                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#contactModal">
                                    <i class="fas fa-envelope"></i> Email
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Resumo Financeiro</h5>
                        </div>
                        <div class="card-body">
                            <?php
                            // Calcular número de diárias
                            $data_entrada = new DateTime($reserva['data_entrada']);
                            $data_saida = new DateTime($reserva['data_saida']);
                            $diff = $data_entrada->diff($data_saida);
                            $num_diarias = $diff->days;
                            
                            // Calcular valores
                            $valor_diarias = $reserva['valor_diaria'] * $num_diarias;
                            $valor_taxas = $reserva['valor_total'] - $valor_diarias;
                            ?>
                            
                            <div class="d-flex justify-content-between mb-2">
                                <span>Diárias (<?php echo $num_diarias; ?> x R$ <?php echo number_format($reserva['valor_diaria'], 2, ',', '.'); ?>)</span>
                                <span>R$ <?php echo number_format($valor_diarias, 2, ',', '.'); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Taxas e Impostos</span>
                                <span>R$ <?php echo number_format($valor_taxas, 2, ',', '.'); ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between fw-bold">
                                <span>Total</span>
                                <span>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Calendário</h5>
                        </div>
                        <div class="card-body">
                            <div id="calendar"></div>
                            
                            <div class="mt-3">
                                <a href="calendario.php?imovel_id=<?php echo $reserva['id_imovel']; ?>&mes=<?php echo date('n', strtotime($reserva['data_entrada'])); ?>&ano=<?php echo date('Y', strtotime($reserva['data_entrada'])); ?>" class="btn btn-outline-primary btn-sm w-100">
                                    <i class="fas fa-calendar-alt"></i> Ver no Calendário Completo
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Contact Modal -->
    <div class="modal fade" id="contactModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Contactar Cliente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="mensagens.php" method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="destinatario_id" value="<?php echo $reserva['id_usuario']; ?>">
                        
                        <div class="mb-3">
                            <label for="assunto" class="form-label">Assunto</label>
                            <input type="text" class="form-control" id="assunto" name="assunto" value="Sobre sua reserva #<?php echo $reserva['codigo']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="mensagem" class="form-label">Mensagem</label>
                            <textarea class="form-control" id="mensagem" name="mensagem" rows="6" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <p><strong>Detalhes da Reserva:</strong></p>
                            <p>Imóvel: <?php echo htmlspecialchars($reserva['imovel_titulo']); ?></p>
                            <p>Check-in: <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?></p>
                            <p>Check-out: <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?></p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" name="enviar_mensagem" class="btn btn-primary">Enviar Mensagem</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Mini calendário para visualização das datas
            // Implementação básica - em produção, usar uma biblioteca como FullCalendar seria mais adequado
            const calendarElement = document.getElementById('calendar');
            
            const dataEntrada = new Date('<?php echo $reserva['data_entrada']; ?>');
            const dataSaida = new Date('<?php echo $reserva['data_saida']; ?>');
            
            function renderCalendar() {
                const mes = dataEntrada.getMonth();
                const ano = dataEntrada.getFullYear();
                
                const primeiroDia = new Date(ano, mes, 1);
                const ultimoDia = new Date(ano, mes + 1, 0);
                
                let html = '<div class="mini-calendar">';
                html += '<div class="calendar-header">';
                html += `<h6>${primeiroDia.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h6>`;
                html += '</div>';
                
                // Dias da semana
                html += '<div class="days-of-week">';
                html += '<div>D</div><div>S</div><div>T</div><div>Q</div><div>Q</div><div>S</div><div>S</div>';
                html += '</div>';
                
                html += '<div class="days-grid">';
                
                // Dias vazios no início
                const diaSemanaInicio = primeiroDia.getDay();
                for (let i = 0; i < diaSemanaInicio; i++) {
                    html += '<div class="day empty"></div>';
                }
                
                // Dias do mês
                for (let i = 1; i <= ultimoDia.getDate(); i++) {
                    const currentDate = new Date(ano, mes, i);
                    
                    let classes = 'day';
                    
                    if (currentDate.getTime() === dataEntrada.getTime()) {
                        classes += ' checkin';
                    } else if (currentDate.getTime() === dataSaida.getTime()) {
                        classes += ' checkout';
                    } else if (currentDate > dataEntrada && currentDate < dataSaida) {
                        classes += ' reserved';
                    }
                    
                    html += `<div class="${classes}">${i}</div>`;
                }
                
                html += '</div></div>';
                
                html += '<div class="calendar-legend mt-2">';
                html += '<div><span class="legend-item checkin"></span> Check-in</div>';
                html += '<div><span class="legend-item checkout"></span> Check-out</div>';
                html += '<div><span class="legend-item reserved"></span> Reservado</div>';
                html += '</div>';
                
                calendarElement.innerHTML = html;
            }
            
            renderCalendar();
            
            // Estilos para o mini calendário
            const style = document.createElement('style');
            style.textContent = `
                .mini-calendar {
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    overflow: hidden;
                }
                
                .calendar-header {
                    background-color: #f8f9fa;
                    padding: 8px;
                    text-align: center;
                }
                
                .days-of-week {
                    display: grid;
                    grid-template-columns: repeat(7, 1fr);
                    text-align: center;
                    background-color: #f8f9fa;
                    font-size: 0.8rem;
                    font-weight: bold;
                }
                
                .days-grid {
                    display: grid;
                    grid-template-columns: repeat(7, 1fr);
                }
                
                .day {
                    height: 30px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    font-size: 0.8rem;
                }
                
                .day.empty {
                    background-color: #f9f9f9;
                }
                
                .day.checkin {
                    background-color: #28a745;
                    color: white;
                    font-weight: bold;
                }
                
                .day.checkout {
                    background-color: #dc3545;
                    color: white;
                    font-weight: bold;
                }
                
                .day.reserved {
                    background-color: #f0f0f0;
                }
                
                .calendar-legend {
                    display: flex;
                    justify-content: space-around;
                    font-size: 0.75rem;
                }
                
                .legend-item {
                    display: inline-block;
                    width: 12px;
                    height: 12px;
                    margin-right: 4px;
                    border-radius: 2px;
                }
                
                .legend-item.checkin {
                    background-color: #28a745;
                }
                
                .legend-item.checkout {
                    background-color: #dc3545;
                }
                
                .legend-item.reserved {
                    background-color: #f0f0f0;
                }
            `;
            document.head.appendChild(style);
        });
    </script>
</body>
</html>