<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

// Processar ações
if (isset($_GET['action']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    
    // Verificar se a reserva pertence a um imóvel do proprietário
    $stmt = $pdo->prepare("
        SELECT r.id 
        FROM reservas r
        JOIN imoveis i ON r.id_imovel = i.id
        WHERE r.id = ? AND i.id_proprietario = ?
    ");
    $stmt->execute([$id, $user_id]);
    
    if ($stmt->rowCount() === 0) {
        $_SESSION['error'] = "Operação não permitida";
        redirect('reservas.php');
    }
    
    switch ($action) {
        case 'confirm':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'confirmada' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Reserva confirmada com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao confirmar reserva: " . $e->getMessage();
            }
            break;
            
        case 'cancel':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'cancelada' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Reserva cancelada com sucesso!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao cancelar reserva: " . $e->getMessage();
            }
            break;
            
        case 'complete':
            try {
                $stmt = $pdo->prepare("UPDATE reservas SET status = 'concluida' WHERE id = ?");
                $stmt->execute([$id]);
                $_SESSION['success'] = "Reserva marcada como concluída!";
            } catch (PDOException $e) {
                $_SESSION['error'] = "Erro ao concluir reserva: " . $e->getMessage();
            }
            break;
    }
    
    redirect('reservas.php');
}

// Paginação
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Filtros
$status = isset($_GET['status']) ? $_GET['status'] : '';
$imovel = isset($_GET['imovel']) ? intval($_GET['imovel']) : 0;
$data_inicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : '';
$data_fim = isset($_GET['data_fim']) ? $_GET['data_fim'] : '';

// Construir consulta
$where = "WHERE i.id_proprietario = ?";
$params = [$_SESSION['user_id']];

if (!empty($status)) {
    $where .= " AND r.status = ?";
    $params[] = $status;
}

if ($imovel > 0) {
    $where .= " AND r.id_imovel = ?";
    $params[] = $imovel;
}

if (!empty($data_inicio)) {
    $where .= " AND r.data_entrada >= ?";
    $params[] = $data_inicio;
}

if (!empty($data_fim)) {
    $where .= " AND r.data_saida <= ?";
    $params[] = $data_fim;
}

// Total de registros
$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM reservas r
    JOIN imoveis i ON r.id_imovel = i.id
    $where
");
$stmt->execute($params);
$total_reservas = $stmt->fetchColumn();
$total_pages = ceil($total_reservas / $limit);

// Buscar reservas
$sql = "
    SELECT r.*, u.nome as usuario_nome, u.email as usuario_email, u.telefone as usuario_telefone,
           i.titulo as imovel_titulo, i.cidade as imovel_cidade, i.estado as imovel_estado
    FROM reservas r
    JOIN usuarios u ON r.id_usuario = u.id
    JOIN imoveis i ON r.id_imovel = i.id
    $where
    ORDER BY r.data_entrada DESC
    LIMIT ?, ?
";
$params[] = $offset;
$params[] = $limit;
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar imóveis do proprietário para o filtro
$stmt = $pdo->prepare("SELECT id, titulo FROM imoveis WHERE id_proprietario = ? ORDER BY titulo");
$stmt->execute([$_SESSION['user_id']]);
$imoveis_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Reservas - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Gerenciar Reservas</h2>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="dashboard-filters">
                <div class="card">
                    <div class="card-body">
                        <form action="reservas.php" method="GET" class="row g-3">
                            <div class="col-md-3">
                                <select name="status" class="form-select">
                                    <option value="">Todos os status</option>
                                    <option value="pendente" <?php echo $status === 'pendente' ? 'selected' : ''; ?>>Pendente</option>
                                    <option value="confirmada" <?php echo $status === 'confirmada' ? 'selected' : ''; ?>>Confirmada</option>
                                    <option value="cancelada" <?php echo $status === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                                    <option value="concluida" <?php echo $status === 'concluida' ? 'selected' : ''; ?>>Concluída</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="imovel" class="form-select">
                                    <option value="0">Todos os imóveis</option>
                                    <?php foreach ($imoveis_list as $im): ?>
                                        <option value="<?php echo $im['id']; ?>" <?php echo $imovel === $im['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($im['titulo']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="data_inicio" class="form-control" placeholder="Data início" value="<?php echo $data_inicio; ?>">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="data_fim" class="form-control" placeholder="Data fim" value="<?php echo $data_fim; ?>">
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-table">
                <div class="card">
                    <div class="card-body">
                        <?php if (empty($reservas)): ?>
                            <div class="alert alert-info">
                                <p>Nenhuma reserva encontrada.</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Código</th>
                                            <th>Imóvel</th>
                                            <th>Cliente</th>
                                            <th>Período</th>
                                            <th>Valor Total</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reservas as $reserva): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($reserva['codigo']); ?></td>
                                                <td><?php echo htmlspecialchars($reserva['imovel_titulo']); ?></td>
                                                <td>
                                                    <?php echo htmlspecialchars($reserva['usuario_nome']); ?><br>
                                                    <small><?php echo htmlspecialchars($reserva['usuario_email']); ?></small>
                                                </td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($reserva['data_entrada'])); ?> a 
                                                    <?php echo date('d/m/Y', strtotime($reserva['data_saida'])); ?>
                                                </td>
                                                <td>R$ <?php echo number_format($reserva['valor_total'], 2, ',', '.'); ?></td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    $status_text = '';
                                                    
                                                    switch ($reserva['status']) {
                                                        case 'pendente':
                                                            $status_class = 'bg-warning';
                                                            $status_text = 'Pendente';
                                                            break;
                                                        case 'confirmada':
                                                            $status_class = 'bg-success';
                                                            $status_text = 'Confirmada';
                                                            break;
                                                        case 'cancelada':
                                                            $status_class = 'bg-danger';
                                                            $status_text = 'Cancelada';
                                                            break;
                                                        case 'concluida':
                                                            $status_class = 'bg-secondary';
                                                            $status_text = 'Concluída';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo $status_text; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="reserva-detalhes.php?id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-info" title="Ver Detalhes">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    
                                                    <?php if ($reserva['status'] === 'pendente'): ?>
                                                        <a href="reservas.php?action=confirm&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-success" title="Confirmar">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        <a href="reservas.php?action=cancel&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-danger" title="Cancelar">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php elseif ($reserva['status'] === 'confirmada'): ?>
                                                        <a href="reservas.php?action=complete&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-secondary" title="Marcar como Concluída">
                                                            <i class="fas fa-check-double"></i>
                                                        </a>
                                                        <a href="reservas.php?action=cancel&id=<?php echo $reserva['id']; ?>" class="btn btn-sm btn-danger" title="Cancelar">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-center">
                                        <?php
                                        $query_params = http_build_query([
                                            'status' => $status,
                                            'imovel' => $imovel,
                                            'data_inicio' => $data_inicio,
                                            'data_fim' => $data_fim
                                        ]);
                                        $query_string = !empty($query_params) ? '&' . $query_params : '';
                                        ?>
                                        
                                        <?php if ($page > 1): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=1<?php echo $query_string; ?>">
                                                    <i class="fas fa-angle-double-left"></i>
                                                </a>
                                            </li>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo $query_string; ?>">
                                                    <i class="fas fa-angle-left"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);
                                        
                                        for ($i = $start_page; $i <= $end_page; $i++):
                                        ?>
                                            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                                <a class="page-link" href="?page=<?php echo $i; ?><?php echo $query_string; ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php endfor; ?>
                                        
                                        <?php if ($page < $total_pages): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo $query_string; ?>">
                                                    <i class="fas fa-angle-right"></i>
                                                </a>
                                            </li>
                                            <li class="page-item">
                                                <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo $query_string; ?>">
                                                    <i class="fas fa-angle-double-right"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>