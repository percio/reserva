<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Verificar se o usuário está logado e é proprietário
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'proprietario') {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];

// Processar envio de mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_mensagem'])) {
    $destinatario_id = filter_input(INPUT_POST, 'destinatario_id', FILTER_SANITIZE_NUMBER_INT);
    $assunto = filter_input(INPUT_POST, 'assunto', FILTER_SANITIZE_STRING);
    $mensagem = filter_input(INPUT_POST, 'mensagem', FILTER_SANITIZE_STRING);
    
    if (empty($assunto) || empty($mensagem)) {
        $_SESSION['error'] = "Por favor, preencha todos os campos obrigatórios.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO mensagens (id_remetente, id_destinatario, assunto, mensagem, data_envio)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$user_id, $destinatario_id, $assunto, $mensagem]);
            $_SESSION['success'] = "Mensagem enviada com sucesso!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Erro ao enviar mensagem: " . $e->getMessage();
        }
    }
    
    redirect('mensagens.php');
}

// Marcar mensagem como lida
if (isset($_GET['action']) && $_GET['action'] === 'marcar_lida' && isset($_GET['id'])) {
    $id_mensagem = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    
    try {
        $stmt = $pdo->prepare("
            UPDATE mensagens 
            SET lida = 1, data_leitura = NOW() 
            WHERE id = ? AND id_destinatario = ?
        ");
        $stmt->execute([$id_mensagem, $user_id]);
        $_SESSION['success'] = "Mensagem marcada como lida!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erro ao atualizar mensagem: " . $e->getMessage();
    }
    
    redirect('mensagens.php');
}

// Excluir mensagem
if (isset($_GET['action']) && $_GET['action'] === 'excluir' && isset($_GET['id'])) {
    $id_mensagem = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    
    try {
        $stmt = $pdo->prepare("
            DELETE FROM mensagens 
            WHERE id = ? AND (id_remetente = ? OR id_destinatario = ?)
        ");
        $stmt->execute([$id_mensagem, $user_id, $user_id]);
        $_SESSION['success'] = "Mensagem excluída com sucesso!";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erro ao excluir mensagem: " . $e->getMessage();
    }
    
    redirect('mensagens.php');
}

// Filtrar tipo de mensagens
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : 'recebidas';
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Buscar mensagens
if ($tipo === 'recebidas') {
    $stmt = $pdo->prepare("
        SELECT m.*, u.nome as remetente_nome
        FROM mensagens m
        JOIN usuarios u ON m.id_remetente = u.id
        WHERE m.id_destinatario = ?
        ORDER BY m.data_envio DESC
        LIMIT ?, ?
    ");
    $stmt->execute([$user_id, $offset, $limit]);
    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Total de mensagens para paginação
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM mensagens WHERE id_destinatario = ?
    ");
    $stmt->execute([$user_id]);
    $total_mensagens = $stmt->fetchColumn();
} else {
    $stmt = $pdo->prepare("
        SELECT m.*, u.nome as destinatario_nome
        FROM mensagens m
        JOIN usuarios u ON m.id_destinatario = u.id
        WHERE m.id_remetente = ?
        ORDER BY m.data_envio DESC
        LIMIT ?, ?
    ");
    $stmt->execute([$user_id, $offset, $limit]);
    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Total de mensagens para paginação
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM mensagens WHERE id_remetente = ?
    ");
    $stmt->execute([$user_id]);
    $total_mensagens = $stmt->fetchColumn();
}

$total_pages = ceil($total_mensagens / $limit);

// Buscar todos os administradores para o formulário de nova mensagem
$stmt = $pdo->prepare("
    SELECT id, nome, email FROM usuarios WHERE tipo = 'admin'
");
$stmt->execute();
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens - AlugaFácil</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Mensagens</h2>
                </div>
                <div class="dashboard-actions">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newMessageModal">
                        <i class="fas fa-plus-circle"></i> Nova Mensagem
                    </button>
                </div>
            </div>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error']; 
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-body">
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $tipo === 'recebidas' ? 'active' : ''; ?>" href="mensagens.php?tipo=recebidas">
                                <i class="fas fa-inbox"></i> Recebidas
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $tipo === 'enviadas' ? 'active' : ''; ?>" href="mensagens.php?tipo=enviadas">
                                <i class="fas fa-paper-plane"></i> Enviadas
                            </a>
                        </li>
                    </ul>
                    
                    <div class="table-responsive mt-3">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th style="width: 5%">Status</th>
                                    <th style="width: 20%">
                                        <?php echo $tipo === 'recebidas' ? 'Remetente' : 'Destinatário'; ?>
                                    </th>
                                    <th style="width: 40%">Assunto</th>
                                    <th style="width: 20%">Data</th>
                                    <th style="width: 15%">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($mensagens)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Nenhuma mensagem encontrada</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($mensagens as $mensagem): ?>
                                        <tr class="<?php echo ($tipo === 'recebidas' && !$mensagem['lida']) ? 'table-active fw-bold' : ''; ?>">
                                            <td>
                                                <?php if ($tipo === 'recebidas'): ?>
                                                    <?php if ($mensagem['lida']): ?>
                                                        <i class="fas fa-envelope-open text-muted" title="Lida"></i>
                                                    <?php else: ?>
                                                        <i class="fas fa-envelope text-primary" title="Não lida"></i>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <i class="fas fa-paper-plane text-info" title="Enviada"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($tipo === 'recebidas' ? $mensagem['remetente_nome'] : $mensagem['destinatario_nome']); ?>
                                            </td>
                                            <td>
                                                <?php echo htmlspecialchars($mensagem['assunto']); ?>
                                            </td>
                                            <td>
                                                <?php echo date('d/m/Y H:i', strtotime($mensagem['data_envio'])); ?>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewMessageModal<?php echo $mensagem['id']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                
                                                <?php if ($tipo === 'recebidas' && !$mensagem['lida']): ?>
                                                    <a href="mensagens.php?action=marcar_lida&id=<?php echo $mensagem['id']; ?>" class="btn btn-sm btn-success" title="Marcar como lida">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $mensagem['id']; ?>" title="Excluir">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                
                                                <!-- View Message Modal -->
                                                <div class="modal fade" id="viewMessageModal<?php echo $mensagem['id']; ?>" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"><?php echo htmlspecialchars($mensagem['assunto']); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><strong>
                                                                    <?php echo $tipo === 'recebidas' ? 'De: ' : 'Para: '; ?>
                                                                </strong> 
                                                                <?php echo htmlspecialchars($tipo === 'recebidas' ? $mensagem['remetente_nome'] : $mensagem['destinatario_nome']); ?>
                                                                </p>
                                                                <p><strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($mensagem['data_envio'])); ?></p>
                                                                <hr>
                                                                <div class="message-content">
                                                                    <?php echo nl2br(htmlspecialchars($mensagem['mensagem'])); ?>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <?php if ($tipo === 'recebidas'): ?>
                                                                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#replyMessageModal<?php echo $mensagem['id']; ?>">
                                                                        <i class="fas fa-reply"></i> Responder
                                                                    </button>
                                                                <?php endif; ?>
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- Reply Message Modal -->
                                                <?php if ($tipo === 'recebidas'): ?>
                                                    <div class="modal fade" id="replyMessageModal<?php echo $mensagem['id']; ?>" tabindex="-1" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Responder Mensagem</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <form action="mensagens.php" method="POST">
                                                                    <div class="modal-body">
                                                                        <input type="hidden" name="destinatario_id" value="<?php echo $mensagem['id_remetente']; ?>">
                                                                        
                                                                        <div class="mb-3">
                                                                            <label for="assunto" class="form-label">Assunto</label>
                                                                            <input type="text" class="form-control" id="assunto" name="assunto" value="RE: <?php echo htmlspecialchars($mensagem['assunto']); ?>" required>
                                                                        </div>
                                                                        
                                                                        <div class="mb-3">
                                                                            <label for="mensagem" class="form-label">Mensagem</label>
                                                                            <textarea class="form-control" id="mensagem" name="mensagem" rows="6" required></textarea>
                                                                        </div>
                                                                        
                                                                        <div class="mb-3">
                                                                            <p><strong>Mensagem original:</strong></p>
                                                                            <div class="original-message p-3 bg-light">
                                                                                <p><strong>De:</strong> <?php echo htmlspecialchars($mensagem['remetente_nome']); ?></p>
                                                                                <p><strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($mensagem['data_envio'])); ?></p>
                                                                                <p><strong>Assunto:</strong> <?php echo htmlspecialchars($mensagem['assunto']); ?></p>
                                                                                <hr>
                                                                                <p><?php echo nl2br(htmlspecialchars($mensagem['mensagem'])); ?></p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                        <button type="submit" name="enviar_mensagem" class="btn btn-primary">Enviar Resposta</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                
                                                <!-- Delete Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo $mensagem['id']; ?>" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Confirmar Exclusão</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Tem certeza que deseja excluir esta mensagem?</p>
                                                                <p><strong>Assunto:</strong> <?php echo htmlspecialchars($mensagem['assunto']); ?></p>
                                                                <p class="text-danger">Esta ação não pode ser desfeita!</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                                <a href="mensagens.php?action=excluir&id=<?php echo $mensagem['id']; ?>" class="btn btn-danger">Excluir</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?tipo=<?php echo $tipo; ?>&page=1">
                                            <i class="fas fa-angle-double-left"></i>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?tipo=<?php echo $tipo; ?>&page=<?php echo $page - 1; ?>">
                                            <i class="fas fa-angle-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);
                                
                                for ($i = $start_page; $i <= $end_page; $i++):
                                ?>
                                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                        <a class="page-link" href="?tipo=<?php echo $tipo; ?>&page=<?php echo $i; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?tipo=<?php echo $tipo; ?>&page=<?php echo $page + 1; ?>">
                                            <i class="fas fa-angle-right"></i>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?tipo=<?php echo $tipo; ?>&page=<?php echo $total_pages; ?>">
                                            <i class="fas fa-angle-double-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- New Message Modal -->
    <div class="modal fade" id="newMessageModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nova Mensagem</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="mensagens.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="destinatario_id" class="form-label">Destinatário</label>
                            <select class="form-select" id="destinatario_id" name="destinatario_id" required>
                                <option value="">Selecione o destinatário</option>
                                <optgroup label="Administradores">
                                    <?php foreach ($admins as $admin): ?>
                                        <option value="<?php echo $admin['id']; ?>">
                                            <?php echo htmlspecialchars($admin['nome'] . ' (' . $admin['email'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </optgroup>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="assunto" class="form-label">Assunto</label>
                            <input type="text" class="form-control" id="assunto" name="assunto" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="mensagem" class="form-label">Mensagem</label>
                            <textarea class="form-control" id="mensagem" name="mensagem" rows="6" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" name="enviar_mensagem" class="btn btn-primary">Enviar Mensagem</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/script.js"></script>
</body>
</html>